COMMODORE 98 WORKBENCH  -  RELEASE 2.0
======================================

Double-click Commodore98.exe. No install, no emulator, no runtime.
The window can be resized and maximized; the desktop grows with it.

DESKTOP
  Double-click an icon to open it. Drag icons anywhere you like on the
  desktop or inside folders; they stay where you put them.
  Drop an icon onto a folder (or the Trash) to move it there, or drag it
  from one folder window to another or onto the desktop.
  Right-click the desktop for New Note, New Folder, Clean Up Icons
  (back into a neat grid), Settings and Refresh.
  Right-click an item to Open, Rename (or F2) or Move to Trash (or Delete).

  TRASH: drag things out of the Trash to get them back, or right-click
  an item inside for Move to Desktop / Delete Permanently. Right-click the
  Trash icon for Empty Trash. Both ask first, and can't be undone.

  Drag windows by the title bar; drag the bottom-right corner of notes,
  folders and Game Maker to resize them. Mouse wheel scrolls text.

  Your notes and folders are real files in the "desktop" folder next to
  Commodore98.exe. Notes save themselves as you type.

SETTINGS (top-left menu or the Settings icon)
  Screen scale   Auto picks a size for your monitor; 1x-4x to choose yourself
  Icon size      Small (compact list) or Large
  Colour theme   C64, Amiga, Teal, Night, Sunset
  Backdrop       Dither, Smooth or Flat
  Boot screen    On / Off
  BASIC screen   40x25 (classic), 52x18, 80x30
  Saved in settings.ini next to the exe.

BASIC 7.0
  Toolbar: Run, Stop, Clear (wipe the screen), Reset (fresh screen and
  colours, your program is kept) and Edit (open the program in Game Maker).
  Type HELP for the command list. ESC = RUN/STOP.

GAME MAKER
  A full editor for BASIC programs. New, Open, Save, Save As, Run, Help.
  Press Example to load DODGE, a complete little game, then Run it.
  Saved programs go to the floppies folder. Ctrl+S saves.
  Game commands: GET K$ (key without waiting, arrows included),
  LOCATE R,C, COLOR F,B, SLEEP N, DIM arrays, SCRN(R,C), PEEK/POKE,
  ON X GOTO. Help in Game Maker lists everything.

YOUR PROGRAM LIBRARY
    floppies\    LOAD"$",8   lists them (DIR works too)
    cassettes\   LOAD        lists them ("PRESS PLAY ON TAPE")
  Each file gets a number. Type RUN and the number, e.g.  RUN 1

  .BAS  BASIC programs (plain text). These run inside Commodore 98.
  .PRG .D64 .T64 .TAP .CRT .G64 .D71 .D81
        Real C64 games. To play them, download the free VICE emulator
        (https://vice-emu.sourceforge.io/, Windows 64-bit) and unzip it
        into the "emulator" folder next to Commodore98.exe. Then RUN and
        the number boots the game in VICE, loaded and started for you.
        Double-clicking a game file on the desktop works too.

  SAVE"NAME" saves the program you typed into floppies\NAME.BAS

SAMPLES INCLUDED
  floppies\DODGE.BAS       dodge the falling rocks (arrow keys)
  floppies\GUESS.BAS       guess the number
  floppies\MAZE.BAS        the classic 10 PRINT maze
  cassettes\DICE_DUEL.BAS  race the computer to 50

Fan-made. Not affiliated with any owner of the Commodore name.

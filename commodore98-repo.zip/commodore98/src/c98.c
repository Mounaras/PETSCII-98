/*  COMMODORE 98 WORKBENCH  -  Release 2.0
    A tiny "what if Commodore survived into the late 90s" desktop with a
    Commodore-style BASIC built in.  Fan-made, not affiliated with any
    Commodore brand owner.

    Builds two ways:
      Windows : native .exe, no runtime, only kernel32/user32/gdi32/shell32
      Other   : a headless test harness that renders to image files
*/
typedef unsigned int u32;
typedef unsigned char u8;

#define MAXW 2560
#define MAXH 1600
static int W = 640, H = 400, SCALE = 1;
static u32 fb[MAXW * MAXH], bgbuf[MAXW * MAXH];
static u32 now_ms;
static int quit_req;

/* ---------- platform services (implemented at the bottom) ---------- */
typedef struct { int year, mon, day, wday, hour, min, sec; } Clock;
typedef void (*DirCb)(const char *name, int isdir, void *ctx);
static void plat_clock(Clock *c);
static void plat_dir(const char *rel, DirCb cb, void *ctx);   /* paths are relative to the exe folder, '/' separated */
static int plat_read(const char *rel, char *buf, int max);    /* bytes read, or -1 */
static int plat_write(const char *rel, const char *data, int len);
static int plat_mkdir(const char *rel);
static int plat_move(const char *from, const char *to);
static int plat_exists(const char *rel);
static int plat_shell(const char *rel);                       /* open with the associated Windows app */
static int plat_emulate(const char *rel);                     /* boot a C64 file in VICE from the emulator folder */
static int plat_delete(const char *rel);                      /* delete a file or a whole folder for good */

#include "font16.h"

/* ---------- tiny libc replacements ---------- */
static int sl(const char *s) { int n = 0; while (s[n]) n++; return n; }
static void scpy(char *d, const char *s) { while ((*d++ = *s++)); }
static void scat(char *d, const char *s) { scpy(d + sl(d), s); }
static void ncpy(char *d, const char *s, int max) { int i = 0; for (; s[i] && i < max - 1; i++) d[i] = s[i]; d[i] = 0; }
static int scmp(const char *a, const char *b) { while (*a && *a == *b) { a++; b++; } return (u8)*a - (u8)*b; }
static int up(int c) { return c >= 'a' && c <= 'z' ? c - 32 : c; }
static int scmpi(const char *a, const char *b) { while (*a && up((u8)*a) == up((u8)*b)) { a++; b++; } return up((u8)*a) - up((u8)*b); }
static void putint_s(char *o, long long v) {
    char t[24]; int n = 0;
    if (v < 0) { *o++ = '-'; v = -v; }
    if (v == 0) t[n++] = '0';
    while (v > 0) { t[n++] = (char)('0' + v % 10); v /= 10; }
    while (n) *o++ = t[--n];
    *o = 0;
}
static int atoi_(const char *s) { int n = 0, neg = 0; while (*s == ' ') s++; if (*s == '-') { neg = 1; s++; } while (*s >= '0' && *s <= '9') n = n * 10 + *s++ - '0'; return neg ? -n : n; }
static double floor_(double x) { long long i = (long long)x; if ((double)i > x) i--; return (double)i; }
static void mmove(char *d, const char *s, int n) {
    if (d < s) for (int i = 0; i < n; i++) d[i] = s[i];
    else for (int i = n - 1; i >= 0; i--) d[i] = s[i];
}
static int mini(int a, int b) { return a < b ? a : b; }
static int maxi(int a, int b) { return a > b ? a : b; }

/* ---------- paths ---------- */
static const char *path_base(const char *p) { const char *b = p; for (; *p; p++) if (*p == '/') b = p + 1; return b; }
static void path_parent(const char *p, char *out) { scpy(out, p); int n = sl(out); while (n > 0 && out[n - 1] != '/') n--; out[n > 0 ? n - 1 : 0] = 0; }
static void path_join(char *out, const char *dir, const char *name) { scpy(out, dir); if (*dir) scat(out, "/"); scat(out, name); }
static const char *ext_of(const char *name) { const char *e = ""; for (const char *p = name; *p; p++) if (*p == '.') e = p + 1; return e; }
static int has_ext(const char *name, const char *ext) { return !scmpi(ext_of(name), ext); }
static void sanitize(char *s) {          /* make a safe file name */
    int k = 0;
    for (int i = 0; s[i]; i++) {
        char c = s[i];
        if (c == '/' || c == '\\' || c == ':' || c == '*' || c == '?' || c == '"' || c == '<' || c == '>' || c == '|' || (u8)c < 32) continue;
        if (k == 0 && (c == ' ' || c == '.')) continue;
        s[k++] = c;
    }
    while (k > 0 && (s[k - 1] == ' ' || s[k - 1] == '.')) k--;
    s[k] = 0;
}
static void uniq_name(const char *dir, const char *base, const char *ext, char *out_name) {
    char rel[256];
    for (int i = 1; i < 1000; i++) {
        scpy(out_name, base);
        if (i > 1) { char b[8]; putint_s(b, i); scat(out_name, " "); scat(out_name, b); }
        scat(out_name, ext);
        path_join(rel, dir, out_name);
        if (!plat_exists(rel)) return;
    }
}

/* ---------- settings & themes ---------- */
typedef struct { int scale, icons, theme, backdrop, boot, bsize; } Settings;
static Settings S = { 0, 1, 0, 0, 1, 1 };
typedef struct { u32 da, db, ta, tb, sel; } Theme;
static const Theme THEMES[5] = {
    { 0x40318D, 0x7869C4, 0x40318D, 0x7869C4, 0x40318D },   /* C64 */
    { 0x4A5A7A, 0x95A5C5, 0x0055AA, 0x6688BB, 0x0055AA },   /* Amiga */
    { 0x174F4F, 0x3FA7A7, 0x1F5F5F, 0x3FA7A7, 0x1F6F6F },   /* Teal */
    { 0x0A0A14, 0x2C2C48, 0x202048, 0x50509A, 0x30306A },   /* Night */
    { 0x4A1A48, 0xE07850, 0x883932, 0xDD8855, 0x883932 } }; /* Sunset */
#define TH (THEMES[S.theme])
static void save_settings(void) {
    char b[200]; b[0] = 0;
    const char *k[6] = { "scale=", "icons=", "theme=", "backdrop=", "boot=", "basic=" };
    int v[6] = { S.scale, S.icons, S.theme, S.backdrop, S.boot, S.bsize };
    for (int i = 0; i < 6; i++) { char n[12]; scat(b, k[i]); putint_s(n, v[i]); scat(b, n); scat(b, "\r\n"); }
    plat_write("settings.ini", b, sl(b));
}
static void load_settings(void) {
    char b[400]; int n = plat_read("settings.ini", b, 399);
    if (n <= 0) return;
    b[n] = 0;
    for (char *p = b; *p;) {
        char *e = p; while (*e && *e != '\n') e++;
        char *eq = p; while (eq < e && *eq != '=') eq++;
        if (eq < e) {
            int v = atoi_(eq + 1);
            *eq = 0;
            if (!scmp(p, "scale") && v >= 0 && v <= 4) S.scale = v;
            if (!scmp(p, "icons") && v >= 0 && v <= 1) S.icons = v;
            if (!scmp(p, "theme") && v >= 0 && v <= 4) S.theme = v;
            if (!scmp(p, "backdrop") && v >= 0 && v <= 2) S.backdrop = v;
            if (!scmp(p, "boot") && v >= 0 && v <= 1) S.boot = v;
            if (!scmp(p, "basic") && v >= 0 && v <= 2) S.bsize = v;
        }
        p = *e ? e + 1 : e;
    }
}

/* ---------- palette ---------- */
static const u32 PAL[16] = {
    0x000000, 0xFFFFFF, 0x883932, 0x67B6BD, 0x8B3F96, 0x55A049, 0x40318D, 0xBFCE72,
    0x8B5429, 0x574200, 0xB86962, 0x505050, 0x787878, 0x94E089, 0x7869C4, 0x9F9F9F };
#define C_BLUE  0x40318D
#define C_LBLUE 0x7869C4
#define FACE    0xC6C6C6
#define HILITE  0xFFFFFF
#define SHADOW  0x7B7B7B
#define DARK    0x000000

/* ---------- drawing ---------- */
static int CX0, CY0, CX1 = 640, CY1 = 400;
static void clip(int x, int y, int w, int h) {
    CX0 = x < 0 ? 0 : x; CY0 = y < 0 ? 0 : y;
    CX1 = x + w > W ? W : x + w; CY1 = y + h > H ? H : y + h;
}
static void noclip(void) { CX0 = 0; CY0 = 0; CX1 = W; CY1 = H; }
static void pset(int x, int y, u32 c) { if (x >= CX0 && x < CX1 && y >= CY0 && y < CY1) fb[y * W + x] = c; }
static void rect(int x, int y, int w, int h, u32 c) {
    int x1 = x + w, y1 = y + h;
    if (x < CX0) x = CX0; if (y < CY0) y = CY0; if (x1 > CX1) x1 = CX1; if (y1 > CY1) y1 = CY1;
    for (int j = y; j < y1; j++) { u32 *p = fb + j * W; for (int i = x; i < x1; i++) p[i] = c; }
}
static void hline(int x, int y, int w, u32 c) { rect(x, y, w, 1, c); }
static void vline(int x, int y, int h, u32 c) { rect(x, y, 1, h, c); }
static void bevel(int x, int y, int w, int h, int raised) {
    u32 a = raised ? HILITE : SHADOW, b = raised ? SHADOW : HILITE;
    hline(x, y, w, a); vline(x, y, h, a); hline(x, y + h - 1, w, b); vline(x + w - 1, y, h, b);
}
static void frame3d(int x, int y, int w, int h) {
    rect(x, y, w, h, FACE);
    hline(x, y, w, HILITE); vline(x, y, h, HILITE);
    hline(x, y + h - 1, w, DARK); vline(x + w - 1, y, h, DARK);
    hline(x + 1, y + h - 2, w - 2, SHADOW); vline(x + w - 2, y + 1, h - 2, SHADOW);
}
static u32 lerp(u32 a, u32 b, int t, int n) {
    if (n <= 0) return a;
    int r = ((a >> 16 & 255) * (n - t) + (b >> 16 & 255) * t) / n;
    int g = ((a >> 8 & 255) * (n - t) + (b >> 8 & 255) * t) / n;
    int l = ((a & 255) * (n - t) + (b & 255) * t) / n;
    return (u32)(r << 16 | g << 8 | l);
}
static void glyph(int x, int y, int ch, u32 c, int k) {
    if (ch == 205 || ch == 206) {                 /* PETSCII diagonals */
        for (int i = 0; i < 8; i++)
            for (int t = 0; t < 2; t++) {
                int px = ch == 205 ? i : 7 - i;
                rect(x + px * k, y + (i * 2 + t) * k, k, k, c);
                if (px < 7) rect(x + (px + 1) * k, y + (i * 2 + t) * k, k, k, c);
            }
        return;
    }
    if (ch == 160) { rect(x, y, 8 * k, 16 * k, c); return; }        /* solid block */
    if (ch == 209) {                                                 /* ball */
        static const u8 ball[16] = { 0, 0, 0, 0x3C, 0x7E, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x7E, 0x3C, 0, 0, 0 };
        for (int r = 0; r < 16; r++) for (int col = 0; col < 8; col++) if (ball[r] & (0x80 >> col)) rect(x + col * k, y + r * k, k, k, c);
        return;
    }
    if (ch < 32 || ch > 126) ch = '?';
    const u8 *g = FONT16[ch - 32];
    for (int r = 0; r < 16; r++)
        for (int col = 0; col < 8; col++)
            if (g[r] & (0x80 >> col)) {
                if (k == 1) pset(x + col, y + r, c); else rect(x + col * k, y + r * k, k, k, c);
            }
}
static void textk(int x, int y, const char *s, u32 c, int k) { for (; *s; s++, x += 8 * k) glyph(x, y, (u8)*s, c, k); }
static void text(int x, int y, const char *s, u32 c) { textk(x, y, s, c, 1); }
static void textb(int x, int y, const char *s, u32 c) { text(x, y, s, c); }   /* the font is already bold */
static void textn(int x, int y, const char *s, int n, u32 c) { for (int i = 0; i < n && s[i]; i++) glyph(x + i * 8, y, (u8)s[i], c, 1); }
static void fit_label(const char *s, int max, char *out) {   /* truncate with ".." */
    int n = sl(s);
    if (n <= max) { scpy(out, s); return; }
    ncpy(out, s, max - 1); scat(out, "..");
}
static void button(int x, int y, int w, const char *label, int down) {
    rect(x, y, w, 18, down ? TH.sel : FACE);
    bevel(x, y, w, 18, !down);
    text(x + (w - sl(label) * 8) / 2, y + 1, label, down ? 0xFFFFFF : 0x000000);
}

/* ---------- icons (16x16 art; drawn at 1x when small, 2x when large) ---------- */
enum { IC_BASIC, IC_NOTE, IC_CLOCK, IC_DISK, IC_FOLDER, IC_GEAR, IC_JOY, IC_PROG, IC_TRASH, NICONS };
static const char *ICONS[NICONS][16] = {
 { "................", ".kkkkkkkkkkkkkk.", ".kggggggggggggk.", ".kgbbbbbbbbbbgk.", ".kgbllblllblbgk.", ".kgbbbbbbbbbbgk.",
   ".kgblllllbbbbgk.", ".kgbbbbbbbbbbgk.", ".kgblwbbbbbbbgk.", ".kgbbbbbbbbbbgk.", ".kggggggggggggk.", ".kkkkkkkkkkkkkk.",
   "......kggk......", "....kkkkkkkk....", "....kggggggk....", "....kkkkkkkk...." },
 { "..kkkkkkkkkk....", "..kwwwwwwwwkk...", "..kwwwwwwwwkwk..", "..kwddddwwwkkkk.", "..kwwwwwwwwwwwk.", "..kwdddddddddwk.",
   "..kwwwwwwwwwwwk.", "..kwdddddddwwwk.", "..kwwwwwwwwwwwk.", "..kwddddddddwwk.", "..kwwwwwwwwwwwk.", "..kwdddddwwwwwk.",
   "..kwwwwwwwwwwwk.", "..kwwwwwwwwwwwk.", "..kkkkkkkkkkkkk.", "................" },
 { ".....kkkkkk.....", "...kkwwwwwwkk...", "..kwwwwkwwwwwk..", ".kwwwwwkwwwwwwk.", ".kwwwwwkwwwwwwk.", "kwwwwwwkwwwwwwwk",
   "kwwwwwwkwwwwwwwk", "kwwwwwwrkkkkwwwk", "kwwwwwwwwwwwwwwk", "kwwwwwwwwwwwwwwk", ".kwwwwwwwwwwwwk.", ".kwwwwwwwwwwwwk.",
   "..kwwwwwwwwwwk..", "...kkwwwwwwkk...", ".....kkkkkk.....", "................" },
 { "kkkkkkkkkkkkkkk.", "kbbkwwwwwwwkbbbk", "kbbkwwwwwkwkbbbk", "kbbkwwwwwkwkbbbk", "kbbkwwwwwwwkbbbk", "kbbbkkkkkkkbbbbk",
   "kbbbbbbbbbbbbbbk", "kbbwwwwwwwwwwbbk", "kbbwddddddddwbbk", "kbbwwwwwwwwwwbbk", "kbbwddddddwwwbbk", "kbbwwwwwwwwwwbbk",
   "kbbwwwwwwwwwwbbk", "kbbwwwwwwwwwwbbk", "kkkkkkkkkkkkkkkk", "................" },
 { "................", "................", ".kkkkkk.........", ".kyyyyyk........", ".kyyyyyykkkkkkk.", ".kyyyyyyyyyyyyk.",
   ".kkkkkkkkkkkkkk.", ".kyyyyyyyyyyyyk.", ".kyyyyyyyyyyyyk.", ".kyyyyyyyyyyyyk.", ".kyyyyyyyyyyyyk.", ".kyyyyyyyyyyyyk.",
   ".koooooooooooook", ".kkkkkkkkkkkkkk.", "................", "................" },
 { "......kkkk......", "..kk..kggk..kk..", ".kggk.kggk.kggk.", ".kgggkkggkkgggk.", "..kggggggggggk..", "..kgggkkkkgggk..",
   "kkkggk....kggkkk", "kgggk......kgggk", "kgggk......kgggk", "kkkggk....kggkkk", "..kgggkkkkgggk..", "..kggggggggggk..",
   ".kgggkkggkkgggk.", ".kggk.kggk.kggk.", "..kk..kggk..kk..", "......kkkk......" },
 { ".......rr.......", "......rrrr......", "......rwrr......", "......rrrr......", ".......rr.......", ".......kk.......",
   ".......kk.......", ".......kk.......", "..kkkkkkkkkkkk..", ".kddddddddddddk.", ".kdrrdddddddddk.", ".kdrrdddddddddk.",
   ".kddddddddddddk.", "..kkkkkkkkkkkk..", "................", "................" },
 { "..kkkkkkkkkk....", "..kwwwwwwwwkk...", "..kwbbwwwwwkwk..", "..kwbbwbbbbkkkk.", "..kwwwwwwwwwwwk.", "..kwbbwbbbbbbwk.",
   "..kwwwwwwwwwwwk.", "..kwbbwbbbbwwwk.", "..kwwwwwwwwwwwk.", "..kwbbwbbbbbwwk.", "..kwwwwwwwwwwwk.", "..kwbbwbbwwwwwk.",
   "..kwwwwwwwwwwwk.", "..kwwwwwwwwwwwk.", "..kkkkkkkkkkkkk.", "................" },
 { "......kkkk......", "..kkkkkkkkkkkk..", "..kggggggggggk..", "..kkkkkkkkkkkk..", "...kgwgwgwgwk...", "...kgwgwgwgwk...",
   "...kgwgwgwgwk...", "...kgwgwgwgwk...", "...kgwgwgwgwk...", "...kgwgwgwgwk...", "...kgwgwgwgwk...", "...kgwgwgwgwk...",
   "...kgwgwgwgwk...", "....kkkkkkkk....", "................", "................" } };
static u32 icol(char c) {
    switch (c) {
    case 'k': return 0x000000; case 'w': return 0xFFFFFF; case 'g': return 0xB0B0B0;
    case 'd': return 0x505050; case 'b': return C_BLUE;   case 'l': return C_LBLUE;
    case 'r': return 0xC03030; case 'y': return 0xE8C860; case 'o': return 0xB08830;
    }
    return 1; /* transparent */
}
static void icon(int x, int y, int n, int k) {
    for (int r = 0; r < 16; r++)
        for (int c = 0; c < 16; c++) { u32 v = icol(ICONS[n][r][c]); if (v != 1) rect(x + c * k, y + r * k, k, k, v); }
}
static const char *POINTER[16] = {
    "X..........", "XX.........", "XWX........", "XWWX.......", "XWWWX......", "XWWWWX.....",
    "XWWWWWX....", "XWWWWWWX...", "XWWWWWWWX..", "XWWWWWWWWX.", "XWWWWWXXXXX", "XWWXWWX....",
    "XWX.XWWX...", "XX..XWWX...", "X....XWWX..", ".....XXXX.." };

/* ---------- forward declarations ---------- */
static void editor_from_program(void);
static void open_basic_window(void);

/* =====================================================================
   BASIC 7.0 console + interpreter
   ===================================================================== */
#define CMAXW 80
#define CMAXH 30
static const int BSIZE_W[3] = { 40, 52, 80 }, BSIZE_H[3] = { 25, 18, 30 };
static int con_w = 52, con_h = 18;
static u8 cch[CMAXH][CMAXW], ccl[CMAXH][CMAXW];
static int crow, ccolm;
static int c_border = 14, c_bg = 6, c_fg = 14;

static void con_cls(void) {
    for (int r = 0; r < CMAXH; r++) for (int c = 0; c < CMAXW; c++) { cch[r][c] = ' '; ccl[r][c] = (u8)c_fg; }
    crow = ccolm = 0;
}
static void con_scroll(void) {
    for (int r = 1; r < con_h; r++) for (int c = 0; c < con_w; c++) { cch[r - 1][c] = cch[r][c]; ccl[r - 1][c] = ccl[r][c]; }
    for (int c = 0; c < con_w; c++) { cch[con_h - 1][c] = ' '; ccl[con_h - 1][c] = (u8)c_fg; }
}
static void con_nl(void) { ccolm = 0; if (++crow >= con_h) { con_scroll(); crow = con_h - 1; } }
static void con_putc(int ch) {
    if (ch == 147) { con_cls(); return; }
    if (ch == '\n') { con_nl(); return; }
    if ((ch < 32 || ch > 126) && ch != 205 && ch != 206 && ch != 160 && ch != 209) return;
    cch[crow][ccolm] = (u8)ch; ccl[crow][ccolm] = (u8)c_fg;
    if (++ccolm >= con_w) con_nl();
}
static void con_puts(const char *s) { while (*s) con_putc((u8)*s++); }
static void con_putn(long long n) { char b[24]; putint_s(b, n); con_puts(b); }

#define MAXL 600
typedef struct { int num; char t[80]; } PLine;
typedef struct { int s; double n; char str[80]; } Val;
typedef struct { char nm[3]; int s; double n; char str[80]; } Var;
typedef struct { Var *v; double lim, step; int line; const char *pos; } ForF;
typedef struct { int line; const char *pos; } GoF;
typedef struct { char nm[2]; char s; int d1, d2, base; } Arr;
typedef struct { int s; double *np; char *sp; int smax; } LV;

static PLine prog[MAXL]; static int nprog;
static Var vars[120]; static int nvars;
static ForF fors[16]; static int nfor;
static GoF gos[32]; static int ngos;
#define MAXARR 40
#define ANUM 20000
#define ASTR 2000
#define ASL 40
static Arr arrs[MAXARR]; static int narr, anum_used, astr_used;
static double anum[ANUM];
static char astr[ASTR][ASL];
static const char *P;
static char berr[32];
static int jumped, brun, bline, bwait;
static u32 bsleep_until;
static LV binlv;
static char bdirect[80], inbuf[80];
static int inlen;
static u32 rnd_state = 12345;
static int kq[32], kqh, kqt;      /* keys waiting for GET */

static void err(const char *m) { if (!berr[0]) scpy(berr, m); }
static void ws(void) { while (*P == ' ') P++; }
static int isal(int c) { return c >= 'A' && c <= 'Z'; }
static int isdg(int c) { return c >= '0' && c <= '9'; }
static int kwat(const char *q, const char *k) { while (*k) if (*q++ != *k++) return 0; return 1; }
static int kw(const char *k) { ws(); if (!kwat(P, k)) return 0; P += sl(k); return 1; }
static int stopword(const char *q) {
    return kwat(q, "THEN") || kwat(q, "TO") || kwat(q, "STEP") || kwat(q, "AND") || kwat(q, "OR") || kwat(q, "GOTO") || kwat(q, "GOSUB");
}
static void clear_vars(void) { nvars = nfor = ngos = 0; narr = anum_used = astr_used = 0; kqh = kqt = 0; }
static int varname(char *nm, int *s) {
    ws();
    if (!isal(*P)) return 0;
    nm[0] = *P++; nm[1] = 0; nm[2] = 0;
    if ((isal(*P) || isdg(*P)) && !stopword(P)) nm[1] = *P++;
    while ((isal(*P) || isdg(*P)) && !stopword(P)) P++;
    *s = 0;
    if (*P == '$') { *s = 1; P++; }
    return 1;
}
static Var *getvar(const char *nm, int s) {
    for (int i = 0; i < nvars; i++)
        if (vars[i].s == s && vars[i].nm[0] == nm[0] && vars[i].nm[1] == nm[1]) return &vars[i];
    if (nvars >= 120) { err("OUT OF MEMORY"); return &vars[0]; }
    Var *v = &vars[nvars++];
    v->nm[0] = nm[0]; v->nm[1] = nm[1]; v->nm[2] = 0; v->s = s; v->n = 0; v->str[0] = 0;
    return v;
}
static Arr *findarr(const char *nm, int s) {
    for (int i = 0; i < narr; i++) if (arrs[i].s == s && arrs[i].nm[0] == nm[0] && arrs[i].nm[1] == nm[1]) return &arrs[i];
    return 0;
}
static void arr_clear(Arr *a) {
    int n = (a->d1 + 1) * (a->d2 + 1);
    for (int i = 0; i < n; i++) { if (a->s) astr[a->base + i][0] = 0; else anum[a->base + i] = 0; }
}
static Arr *dimarr(const char *nm, int s, int d1, int d2) {
    if (d1 < 0 || d2 < 0) { err("ILLEGAL QUANTITY"); return 0; }
    Arr *a = findarr(nm, s);
    if (a) { if (a->d1 == d1 && a->d2 == d2) { arr_clear(a); return a; } err("REDIM'D ARRAY"); return 0; }
    int n = (d1 + 1) * (d2 + 1);
    if (narr >= MAXARR || (s ? astr_used + n > ASTR : anum_used + n > ANUM)) { err("OUT OF MEMORY"); return 0; }
    a = &arrs[narr++];
    a->nm[0] = nm[0]; a->nm[1] = nm[1]; a->s = (char)s; a->d1 = d1; a->d2 = d2;
    if (s) { a->base = astr_used; astr_used += n; } else { a->base = anum_used; anum_used += n; }
    arr_clear(a);
    return a;
}
static double nexpr(void);
static int expect(int ch) { ws(); if (*P == ch) { P++; return 1; } err("SYNTAX"); return 0; }
static int lvalue(LV *lv) {
    char nm[3]; int s;
    if (!varname(nm, &s)) return 0;
    lv->s = s;
    if (*P == '(') {
        P++;
        int i1 = (int)nexpr(), i2 = 0, two = 0;
        ws(); if (*P == ',') { P++; i2 = (int)nexpr(); two = 1; }
        if (!expect(')') || berr[0]) return 0;
        Arr *a = findarr(nm, s);
        if (!a) a = dimarr(nm, s, 10, two ? 10 : 0);
        if (!a) return 0;
        if (i1 < 0 || i1 > a->d1 || i2 < 0 || i2 > a->d2 || (!two && a->d2)) { err("BAD SUBSCRIPT"); return 0; }
        int idx = a->base + i1 * (a->d2 + 1) + i2;
        if (s) { lv->sp = astr[idx]; lv->smax = ASL; lv->np = 0; } else { lv->np = &anum[idx]; lv->sp = 0; }
        return 1;
    }
    Var *v = getvar(nm, s);
    lv->np = &v->n; lv->sp = v->str; lv->smax = 80;
    return 1;
}
static double parsenum(const char **pp, int *ok) {
    const char *p = *pp; double v = 0; int any = 0, neg = 0;
    while (*p == ' ') p++;
    if (*p == '-') { neg = 1; p++; } else if (*p == '+') p++;
    while (isdg(*p)) { v = v * 10 + (*p - '0'); p++; any = 1; }
    if (*p == '.') { p++; double f = 0.1; while (isdg(*p)) { v += (*p - '0') * f; f *= 0.1; p++; any = 1; } }
    if (any && *p == 'E') {
        const char *q = p + 1; int en = 0, es = 1;
        if (*q == '-') { es = -1; q++; } else if (*q == '+') q++;
        if (isdg(*q)) { while (isdg(*q)) { en = en * 10 + *q - '0'; q++; } p = q; if (en > 300) en = 300; while (en--) v = es > 0 ? v * 10 : v / 10; }
    }
    *ok = any; *pp = p;
    return neg ? -v : v;
}
static void fmtnum(double v, char *o) {
    if (v != v || v > 1.7e38 || v < -1.7e38) { scpy(o, " OVERFLOW"); return; }
    if (v < 0) { *o++ = '-'; v = -v; } else *o++ = ' ';
    if (v < 1e15 && v == (double)(long long)v) { putint_s(o, (long long)v); return; }
    if (v >= 0.01 && v < 1e9) {
        long long ip = (long long)v, t = ip; int d = 0;
        while (t) { d++; t /= 10; }
        int fd = 9 - d; double p = 1;
        for (int i = 0; i < fd; i++) p *= 10;
        long long f = (long long)((v - (double)ip) * p + 0.5);
        if (f >= (long long)p) { ip++; f -= (long long)p; }
        if (ip) { putint_s(o, ip); o += sl(o); }
        char fr[16]; int n = fd;
        for (int i = 0; i < fd; i++) { fr[fd - 1 - i] = (char)('0' + f % 10); f /= 10; }
        while (n > 0 && fr[n - 1] == '0') n--;
        if (n) { *o++ = '.'; for (int i = 0; i < n; i++) *o++ = fr[i]; }
        if (!ip && !n) *o++ = '0';
        *o = 0; return;
    }
    int e = 0;
    while (v >= 10) { v /= 10; e++; }
    while (v < 1) { v *= 10; e--; }
    long long m = (long long)(v * 1e8 + 0.5);
    if (m >= 1000000000LL) { m /= 10; e++; }
    char md[10]; for (int i = 8; i >= 0; i--) { md[i] = (char)('0' + m % 10); m /= 10; }
    int n = 9; while (n > 1 && md[n - 1] == '0') n--;
    *o++ = md[0];
    if (n > 1) { *o++ = '.'; for (int i = 1; i < n; i++) *o++ = md[i]; }
    *o++ = 'E'; *o++ = e < 0 ? '-' : '+'; if (e < 0) e = -e;
    *o++ = (char)('0' + e / 10); *o++ = (char)('0' + e % 10); *o = 0;
}

static Val expr(void);
static Val unary(void);
static Val num(double n) { Val v; v.s = 0; v.n = n; v.str[0] = 0; return v; }
static Val strv(const char *s) { Val v; v.s = 1; v.n = 0; ncpy(v.str, s, 80); return v; }
static double nexpr(void) { Val v = expr(); if (v.s) err("TYPE MISMATCH"); return v.n; }
static void sexpr(char *o) { Val v = expr(); if (!v.s) { err("TYPE MISMATCH"); o[0] = 0; return; } scpy(o, v.str); }
static int prog_bytes(void) { int b = 0; for (int i = 0; i < nprog; i++) b += sl(prog[i].t) + 5; return b; }
static double peek(int a) {
    if (a >= 1024 && a < 1024 + con_w * con_h) { int i = a - 1024; return cch[i / con_w][i % con_w]; }
    if (a >= 55296 && a < 55296 + con_w * con_h) { int i = a - 55296; return ccl[i / con_w][i % con_w]; }
    if (a == 53280) return c_border;
    if (a == 53281) return c_bg;
    if (a == 646) return c_fg;
    if (a == 214) return crow;
    if (a == 211) return ccolm;
    return 0;
}
static double sqrt_(double x) { double g = x > 1 ? x : 1; for (int i = 0; i < 40 && x > 0; i++) g = 0.5 * (g + x / g); return x == 0 ? 0 : g; }

static Val atom(void) {
    char b[80];
    ws();
    if (isdg(*P) || *P == '.') { int ok; double n = parsenum(&P, &ok); return num(n); }
    if (*P == '"') {
        P++; int i = 0;
        while (*P && *P != '"') { if (i < 79) b[i++] = *P; P++; }
        b[i] = 0; if (*P == '"') P++;
        return strv(b);
    }
    if (*P == '(') { P++; Val v = expr(); expect(')'); return v; }
    if (kw("RND(")) { nexpr(); expect(')'); rnd_state = rnd_state * 1103515245u + 12345u; return num(((rnd_state >> 8) & 0xFFFFFF) / 16777216.0); }
    if (kw("INT(")) { double x = nexpr(); expect(')'); return num(floor_(x)); }
    if (kw("ABS(")) { double x = nexpr(); expect(')'); return num(x < 0 ? -x : x); }
    if (kw("SGN(")) { double x = nexpr(); expect(')'); return num(x < 0 ? -1 : x > 0 ? 1 : 0); }
    if (kw("SQR(")) { double x = nexpr(); expect(')'); if (x < 0) { err("ILLEGAL QUANTITY"); return num(0); } return num(sqrt_(x)); }
    if (kw("LEN(")) { sexpr(b); expect(')'); return num(sl(b)); }
    if (kw("ASC(")) { sexpr(b); expect(')'); return num((u8)b[0]); }
    if (kw("VAL(")) { sexpr(b); expect(')'); const char *q = b; int ok; double n = parsenum(&q, &ok); return num(ok ? n : 0); }
    if (kw("STR$(")) { double x = nexpr(); expect(')'); fmtnum(x, b); return strv(b); }
    if (kw("CHR$(")) { int c = (int)nexpr(); expect(')'); b[0] = (char)c; b[1] = 0; return strv(b); }
    if (kw("LEFT$(")) {
        sexpr(b); expect(','); int n = (int)nexpr(); expect(')');
        if (n < 0) n = 0; if (n < sl(b)) b[n] = 0; return strv(b);
    }
    if (kw("RIGHT$(")) {
        sexpr(b); expect(','); int n = (int)nexpr(); expect(')');
        int L = sl(b); if (n > L) n = L; if (n < 0) n = 0; return strv(b + L - n);
    }
    if (kw("MID$(")) {
        sexpr(b); expect(','); int st = (int)nexpr(), n = 255;
        ws(); if (*P == ',') { P++; n = (int)nexpr(); }
        expect(')');
        int L = sl(b); if (st < 1) { err("ILLEGAL QUANTITY"); st = 1; }
        if (st > L) return strv("");
        char *s = b + st - 1; if (n >= 0 && n < sl(s)) s[n] = 0;
        return strv(s);
    }
    if (kw("SCRN(")) {
        int r = (int)nexpr(); expect(','); int c = (int)nexpr(); expect(')');
        if (r < 0 || r >= con_h || c < 0 || c >= con_w) return num(0);
        return num(cch[r][c]);
    }
    if (kw("PEEK(")) { int a = (int)nexpr(); expect(')'); return num(peek(a)); }
    if (kw("FRE(")) { expr(); expect(')'); return num(61439 - prog_bytes()); }
    if (kw("TI$")) {
        Clock c; plat_clock(&c);
        b[0] = (char)('0' + c.hour / 10); b[1] = (char)('0' + c.hour % 10); b[2] = (char)('0' + c.min / 10);
        b[3] = (char)('0' + c.min % 10); b[4] = (char)('0' + c.sec / 10); b[5] = (char)('0' + c.sec % 10); b[6] = 0;
        return strv(b);
    }
    if (kw("TI")) return num((double)(now_ms / 1000u * 60u + (now_ms % 1000u) * 60u / 1000u));
    LV lv;
    if (lvalue(&lv)) return lv.s ? strv(lv.sp) : num(*lv.np);
    err("SYNTAX");
    return num(0);
}
static Val power(void) {
    Val a = atom();
    for (;;) {
        ws();
        if (*P != '^') return a;
        P++;
        Val b = unary();
        if (a.s || b.s) { err("TYPE MISMATCH"); return a; }
        if (b.n != floor_(b.n)) {
            if (b.n == 0.5 && a.n >= 0) { a.n = sqrt_(a.n); continue; }
            err("ILLEGAL QUANTITY"); return a;
        }
        long long e = (long long)b.n; int neg = e < 0; if (neg) e = -e;
        if (e > 2000) { err("OVERFLOW"); return a; }
        double r = 1; while (e--) r *= a.n;
        if (neg) { if (r == 0) { err("DIVISION BY ZERO"); return a; } r = 1 / r; }
        a.n = r;
    }
}
static Val unary(void) {
    ws();
    if (*P == '-') { P++; Val v = unary(); if (v.s) err("TYPE MISMATCH"); v.n = -v.n; return v; }
    if (*P == '+') { P++; return unary(); }
    if (kw("NOT")) { Val v = unary(); return num((double)(~(int)v.n)); }
    return power();
}
static Val mul(void) {
    Val a = unary();
    for (;;) {
        ws(); char op = *P;
        if (op != '*' && op != '/') return a;
        P++;
        Val b = unary();
        if (a.s || b.s) { err("TYPE MISMATCH"); return a; }
        if (op == '/') { if (b.n == 0) { err("DIVISION BY ZERO"); return a; } a.n /= b.n; }
        else a.n *= b.n;
    }
}
static Val add(void) {
    Val a = mul();
    for (;;) {
        ws(); char op = *P;
        if (op != '+' && op != '-') return a;
        P++;
        Val b = mul();
        if (op == '+' && a.s && b.s) {
            int la = sl(a.str);
            if (la + sl(b.str) > 79) { err("STRING TOO LONG"); return a; }
            scpy(a.str + la, b.str);
        } else if (a.s || b.s) { err("TYPE MISMATCH"); return a; }
        else a.n = op == '+' ? a.n + b.n : a.n - b.n;
    }
}
static Val cmp(void) {
    Val a = add();
    ws();
    int op = 0;
    if (P[0] == '<' && P[1] == '>') { op = 1; P += 2; }
    else if (P[0] == '<' && P[1] == '=') { op = 2; P += 2; }
    else if (P[0] == '>' && P[1] == '=') { op = 3; P += 2; }
    else if (*P == '<') { op = 4; P++; }
    else if (*P == '>') { op = 5; P++; }
    else if (*P == '=') { op = 6; P++; }
    if (!op) return a;
    Val b = add();
    if (a.s != b.s) { err("TYPE MISMATCH"); return num(0); }
    int c = a.s ? scmp(a.str, b.str) : (a.n < b.n ? -1 : a.n > b.n ? 1 : 0);
    int r = op == 1 ? c != 0 : op == 2 ? c <= 0 : op == 3 ? c >= 0 : op == 4 ? c < 0 : op == 5 ? c > 0 : c == 0;
    return num(r ? -1 : 0);
}
static Val andx(void) { Val a = cmp(); while (kw("AND")) { Val b = cmp(); a = num((double)((int)a.n & (int)b.n)); } return a; }
static Val expr(void) { Val a = andx(); while (kw("OR")) { Val b = andx(); a = num((double)((int)a.n | (int)b.n)); } return a; }

static void ready(void) { if (ccolm) con_nl(); con_puts("READY.\n"); }
static void banner(void) {
    int pad = (con_w - 32) / 2; for (int i = 0; i < pad; i++) con_putc(' ');
    con_puts("**** COMMODORE 98 BASIC 7.0 ****\n");
    pad = (con_w - 39) / 2; for (int i = 0; i < pad; i++) con_putc(' ');
    con_puts("64MB RAM SYSTEM  61439 BASIC BYTES FREE\n\n");
    con_puts("TYPE HELP FOR COMMANDS. ESC = RUN/STOP.\n");
    ready();
}
static void basic_screen_reset(void) {   /* colours + screen, program is kept */
    c_border = 14; c_bg = 6; c_fg = 14;
    brun = bwait = 0; inlen = 0;
    con_cls(); banner();
}
static int findline(int n) { for (int i = 0; i < nprog; i++) if (prog[i].num == n) return i; return -1; }
static void jumpto(int n) {
    int i = findline(n);
    if (i < 0) { err("UNDEF'D STATEMENT"); return; }
    bline = i; P = prog[i].t; jumped = 1;
}
static int linenum(void) {
    ws();
    if (!isdg(*P)) { err("SYNTAX"); return 0; }
    int n = 0; while (isdg(*P)) n = n * 10 + *P++ - '0';
    return n;
}
static void b_stop(int brk) {
    if (brk) {
        if (ccolm) con_nl();
        con_puts("BREAK");
        if (bline >= 0 && bline < nprog) { con_puts(" IN "); con_putn(prog[bline].num); }
        con_nl();
    }
    brun = 0; bwait = 0;
    ready();
}
static void b_print(void) {
    int nl = 1;
    for (;;) {
        ws(); char c = *P;
        if (c == 0 || c == ':') break;
        if (c == ';') { P++; nl = 0; continue; }
        if (c == ',') { P++; nl = 0; do con_putc(' '); while (ccolm % 10); continue; }
        if (kw("SPC(")) { int n = (int)nexpr(); expect(')'); while (n-- > 0) con_putc(' '); nl = 1; continue; }
        if (kw("TAB(")) { int n = (int)nexpr(); expect(')'); while (ccolm < n && ccolm < con_w - 1) con_putc(' '); nl = 1; continue; }
        Val v = expr();
        if (berr[0]) return;
        if (v.s) con_puts(v.str);
        else { char b[32]; fmtnum(v.n, b); con_puts(b); con_putc(' '); }
        nl = 1;
    }
    if (nl) con_nl();
}
static void b_input(void) {
    if (bline < 0) { err("ILLEGAL DIRECT"); return; }
    ws();
    if (*P == '"') {
        P++; while (*P && *P != '"') con_putc((u8)*P++);
        if (*P == '"') P++;
        if (!expect(';')) return;
    }
    if (!lvalue(&binlv)) { err("SYNTAX"); return; }
    con_puts("? "); bwait = 1; inlen = 0;
}
static void b_get(void) {
    LV lv;
    if (!lvalue(&lv)) { err("SYNTAX"); return; }
    int k = 0;
    if (kqh != kqt) { k = kq[kqh]; kqh = (kqh + 1) % 32; }
    if (lv.s) { lv.sp[0] = (char)k; lv.sp[1] = 0; }
    else *lv.np = k;
}
static void b_let(void) {
    LV lv;
    if (!lvalue(&lv)) { err("SYNTAX"); return; }
    if (!expect('=')) return;
    Val v = expr();
    if (berr[0]) return;
    if (v.s != lv.s) { err("TYPE MISMATCH"); return; }
    if (lv.s) ncpy(lv.sp, v.str, lv.smax); else *lv.np = v.n;
}
static void b_dim(void) {
    for (;;) {
        char nm[3]; int s;
        if (!varname(nm, &s)) { err("SYNTAX"); return; }
        if (!expect('(')) return;
        int d1 = (int)nexpr(), d2 = 0;
        ws(); if (*P == ',') { P++; d2 = (int)nexpr(); }
        if (!expect(')') || berr[0]) return;
        if (!dimarr(nm, s, d1, d2)) return;
        ws(); if (*P != ',') return;
        P++;
    }
}
static void b_for(void) {
    char nm[3]; int s;
    if (!varname(nm, &s) || s) { err("SYNTAX"); return; }
    if (!expect('=')) return;
    double a = nexpr();
    if (!kw("TO")) { err("SYNTAX"); return; }
    double b = nexpr(), st = 1;
    if (kw("STEP")) st = nexpr();
    if (berr[0]) return;
    Var *v = getvar(nm, 0); v->n = a;
    int i; for (i = 0; i < nfor; i++) if (fors[i].v == v) break;
    if (i < nfor) nfor = i;
    if (nfor >= 16) { err("OUT OF MEMORY"); return; }
    ForF *f = &fors[nfor++];
    f->v = v; f->lim = b; f->step = st; f->line = bline; f->pos = P;
}
static void b_next(void) {
    int i = nfor - 1;
    ws();
    if (isal(*P)) {
        char nm[3]; int s; varname(nm, &s);
        Var *v = getvar(nm, 0);
        for (; i >= 0; i--) if (fors[i].v == v) break;
    }
    if (i < 0) { err("NEXT WITHOUT FOR"); return; }
    nfor = i + 1;
    ForF *f = &fors[i];
    f->v->n += f->step;
    if (f->step >= 0 ? f->v->n <= f->lim : f->v->n >= f->lim) { bline = f->line; P = f->pos; jumped = 1; }
    else nfor--;
}
static void b_if(void) {
    double c = nexpr();
    if (berr[0]) return;
    int th = kw("THEN");
    if (!th && !kw("GOTO")) { err("SYNTAX"); return; }
    if (c == 0) { P += sl(P); return; }
    ws();
    if (isdg(*P) || !th) { int n = linenum(); if (!berr[0]) jumpto(n); return; }
    jumped = 1;  /* carry on with the statement after THEN */
}
static void b_gosub_to(int n) {
    if (ngos >= 32) { err("OUT OF MEMORY"); return; }
    gos[ngos].line = bline; gos[ngos].pos = P; ngos++;
    jumpto(n);
}
static void b_on(void) {
    int v = (int)nexpr();
    int go = kw("GOTO"), gs = !go && kw("GOSUB");
    if (!go && !gs) { err("SYNTAX"); return; }
    int nums[16], n = 0;
    for (;;) {
        int x = linenum(); if (berr[0]) return;
        if (n < 16) nums[n++] = x;
        ws(); if (*P != ',') break;
        P++;
    }
    if (v < 1 || v > n) return;
    if (gs) b_gosub_to(nums[v - 1]); else jumpto(nums[v - 1]);
}
static void b_return(void) {
    if (!ngos) { err("RETURN WITHOUT GOSUB"); return; }
    ngos--; bline = gos[ngos].line; P = gos[ngos].pos; jumped = 1;
}
static int cat_active, cat_n;
static void start_entry(int i, int autorun);
static void b_run(void) {
    ws();
    if (isdg(*P)) {
        int n = linenum();
        if (cat_active && n >= 1 && n <= cat_n) { start_entry(n - 1, 1); return; }
        clear_vars();
        jumpto(n); return;
    }
    clear_vars();
    if (nprog) { bline = 0; P = prog[0].t; jumped = 1; }
}
static void b_list(void) {
    int a = 0, b = 999999;
    ws();
    if (isdg(*P)) { a = b = linenum(); }
    ws();
    if (*P == '-') { P++; ws(); b = isdg(*P) ? linenum() : 999999; }
    for (int i = 0; i < nprog; i++)
        if (prog[i].num >= a && prog[i].num <= b) { con_putn(prog[i].num); con_putc(' '); con_puts(prog[i].t); con_nl(); }
}
static void b_poke(void) {
    int a = (int)nexpr();
    if (!expect(',')) return;
    int v = (int)nexpr();
    if (a == 53280) c_border = v & 15;
    else if (a == 53281) c_bg = v & 15;
    else if (a == 646) c_fg = v & 15;
    else if (a >= 1024 && a < 1024 + con_w * con_h) { int i = a - 1024; cch[i / con_w][i % con_w] = (u8)v; ccl[i / con_w][i % con_w] = (u8)c_fg; }
    else if (a >= 55296 && a < 55296 + con_w * con_h) { int i = a - 55296; ccl[i / con_w][i % con_w] = (u8)(v & 15); }
}
static void b_locate(void) {
    int r = (int)nexpr();
    if (!expect(',')) return;
    int c = (int)nexpr();
    if (berr[0]) return;
    crow = r < 0 ? 0 : r >= con_h ? con_h - 1 : r;
    ccolm = c < 0 ? 0 : c >= con_w ? con_w - 1 : c;
}
static void b_color(void) {
    int f = (int)nexpr();
    c_fg = f & 15;
    ws(); if (*P == ',') { P++; c_bg = (int)nexpr() & 15; }
    ws(); if (*P == ',') { P++; c_border = (int)nexpr() & 15; }
}
static void b_help(void) {
    con_puts("COMMANDS: RUN LIST NEW CLS CLR HELP EDIT\n");
    con_puts("PRINT INPUT GET LET DIM IF..THEN GOTO GOSUB\n");
    con_puts("RETURN ON..GOTO FOR..TO..STEP NEXT END STOP\n");
    con_puts("REM POKE SYS LOCATE R,C COLOR F,B SLEEP N\n");
    con_puts("FUNCTIONS: RND INT ABS SGN SQR LEN ASC VAL\n");
    con_puts("STR$ CHR$ LEFT$ RIGHT$ MID$ SCRN PEEK FRE TI\n");
    con_puts("LOAD\"$\",8 = FLOPPIES  LOAD = CASSETTES\n");
    con_puts("RUN N = START PROGRAM N  SAVE\"NAME\" = SAVE\n");
    con_puts("EDIT = OPEN THIS PROGRAM IN GAME MAKER\n");
}

/* ---------- program text <-> lines ---------- */
static void storeline(int n, const char *t) {
    int i = findline(n);
    if (i >= 0) { for (int j = i; j < nprog - 1; j++) prog[j] = prog[j + 1]; nprog--; }
    cat_active = 0;
    if (!*t) return;
    if (nprog >= MAXL) { con_puts("?OUT OF MEMORY  ERROR\n"); return; }
    i = 0; while (i < nprog && prog[i].num < n) i++;
    for (int j = nprog; j > i; j--) prog[j] = prog[j - 1];
    prog[i].num = n; ncpy(prog[i].t, t, 80); nprog++;
}
static int parse_program(char *text, int *skipped) {   /* replaces the program; returns lines */
    nprog = 0; clear_vars(); *skipped = 0;
    char *p = text;
    while (*p) {
        char *e = p; while (*e && *e != '\n') e++;
        char hold = *e; *e = 0;
        char ln[80]; int k = 0, inq = 0;
        for (char *q = p; *q && k < 79; q++) {
            char c = *q;
            if (c == '\r') continue;
            if (c == '\t') c = ' ';
            if (c == '"') inq = !inq;
            if (!inq || 1) c = (char)up((u8)c);
            ln[k++] = c;
        }
        ln[k] = 0;
        const char *q = ln; while (*q == ' ') q++;
        if (isdg(*q)) {
            int num = 0; while (isdg(*q)) num = num * 10 + *q++ - '0';
            while (*q == ' ') q++;
            if (*q) storeline(num, q);
        } else if (*q) (*skipped)++;
        *e = hold; p = *e ? e + 1 : e;
    }
    cat_active = 0;
    return nprog;
}
static int program_to_text(char *out, int max, int crlf) {
    int n = 0;
    for (int i = 0; i < nprog && n < max - 100; i++) {
        putint_s(out + n, prog[i].num); n += sl(out + n);
        out[n++] = ' ';
        scpy(out + n, prog[i].t); n += sl(prog[i].t);
        if (crlf) out[n++] = '\r';
        out[n++] = '\n';
    }
    out[n] = 0;
    return n;
}

/* ---------- cassettes & floppies ---------- */
#define MAXCAT 64
static char cat_rel[MAXCAT][200], cat_name[MAXCAT][40], cat_ext[MAXCAT][5];
static char loadbuf[40000];
static int known_ext(const char *e) {
    static const char *k[] = { "BAS", "TXT", "PRG", "D64", "T64", "TAP", "CRT", "G64", "D71", "D81", "P00", 0 };
    for (int i = 0; k[i]; i++) if (!scmpi(e, k[i])) return 1;
    return 0;
}
static int is_basic_ext(const char *e) { return !scmpi(e, "BAS") || !scmpi(e, "TXT"); }
static void cat_cb(const char *name, int isdir, void *ctx) {
    if (isdir || cat_n >= MAXCAT || name[0] == '.') return;
    const char *e = ext_of(name);
    if (!*e || sl(e) > 4 || !known_ext(e)) return;
    path_join(cat_rel[cat_n], (const char *)ctx, name);
    int k = 0;
    for (const char *p = name; p < e - 1 && k < 36; p++) {
        int c = up((u8)*p); if (c == '_') c = ' ';
        cat_name[cat_n][k++] = (char)(c >= 32 && c < 127 ? c : '?');
    }
    cat_name[cat_n][k] = 0;
    for (k = 0; e[k]; k++) cat_ext[cat_n][k] = (char)up((u8)e[k]);
    cat_ext[cat_n][k] = 0;
    cat_n++;
}
static void cat_swap(int a, int b) {
    char t[200];
    scpy(t, cat_rel[a]); scpy(cat_rel[a], cat_rel[b]); scpy(cat_rel[b], t);
    scpy(t, cat_name[a]); scpy(cat_name[a], cat_name[b]); scpy(cat_name[b], t);
    scpy(t, cat_ext[a]); scpy(cat_ext[a], cat_ext[b]); scpy(cat_ext[b], t);
}
static int scan_cat(int mask) {
    cat_n = 0;
    for (int d = 0; d < 2; d++) {
        if (!(mask & (1 << d))) continue;
        int first = cat_n;
        plat_dir(d ? "floppies" : "cassettes", cat_cb, (void *)(d ? "floppies" : "cassettes"));
        for (int i = first + 1; i < cat_n; i++)
            for (int j = i; j > first && scmp(cat_name[j - 1], cat_name[j]) > 0; j--) cat_swap(j - 1, j);
    }
    return cat_n;
}
static void pad_puts(const char *s, int w) { con_puts(s); for (int i = sl(s); i < w; i++) con_putc(' '); }
static void show_catalog(int mask) {
    const char *dir = mask == 1 ? "CASSETTES" : "FLOPPIES";
    if (mask == 1) con_puts("PRESS PLAY ON TAPE\nOK\n");
    else con_puts("SEARCHING FOR $\n");
    scan_cat(mask);
    cat_active = 1;
    con_puts("LOADING\n\n");
    con_puts("0 \""); pad_puts(dir, 16); con_puts("\" 98 2A\n");
    if (!cat_n) {
        con_puts("NO PROGRAMS FOUND. PUT GAMES IN THE\n");
        con_puts(dir); con_puts(" FOLDER NEXT TO COMMODORE98.EXE\n");
        cat_active = 0;
        return;
    }
    int nw = con_w - 10; if (nw > 36) nw = 36;
    for (int i = 0; i < cat_n; i++) {
        if (i + 1 < 10) con_putc(' ');
        con_putn(i + 1); con_puts(". ");
        char lab[40]; fit_label(cat_name[i], nw, lab);
        pad_puts(lab, nw); con_puts(cat_ext[i]); con_nl();
    }
    con_puts("\nTYPE RUN AND A NUMBER, E.G. RUN 1\n");
}
static int load_basic_file(const char *rel) {
    int n = plat_read(rel, loadbuf, (int)sizeof loadbuf - 1);
    if (n < 0) { err("FILE NOT FOUND"); return 0; }
    loadbuf[n] = 0;
    int skipped;
    if (!parse_program(loadbuf, &skipped)) { err("NO BASIC LINES IN FILE"); return 0; }
    return 1;
}
static void start_entry(int i, int autorun) {
    con_puts(autorun ? "STARTING " : "LOADING "); con_puts(cat_name[i]); con_nl();
    if (is_basic_ext(cat_ext[i])) {
        if (!load_basic_file(cat_rel[i])) return;
        if (autorun) { bline = 0; P = prog[0].t; jumped = 1; }
        return;
    }
    if (plat_emulate(cat_rel[i])) { con_puts("BOOTING IT IN VICE...\n"); return; }
    if (plat_shell(cat_rel[i])) { con_puts("OPENED IN YOUR C64 EMULATOR.\n"); return; }
    con_puts("."); con_puts(cat_ext[i]); con_puts(" FILES ARE REAL C64 MACHINE CODE.\n");
    con_puts("DOWNLOAD VICE (VICE-EMU.SOURCEFORGE.IO)\n");
    con_puts("AND UNZIP IT INTO THE EMULATOR FOLDER\n");
    con_puts("NEXT TO COMMODORE98.EXE.\n");
    err("NO EMULATOR FOUND");
}
static void quoted_name(char *name, int max) {
    name[0] = 0; ws();
    if (*P == '"') {
        P++; int k = 0;
        while (*P && *P != '"') { if (k < max - 1) name[k++] = *P; P++; }
        name[k] = 0; if (*P == '"') P++;
    }
}
static void b_load(void) {
    char name[80];
    quoted_name(name, 80);
    int dev = 1;
    ws();
    if (*P == ',') { P++; ws(); dev = 0; while (isdg(*P)) dev = dev * 10 + *P++ - '0'; }
    P += sl(P);
    if (!name[0]) { if (dev >= 8) err("MISSING FILE NAME"); else show_catalog(1); return; }
    if (!scmp(name, "$")) { show_catalog(2); return; }
    int masks[2] = { dev >= 8 ? 2 : 1, dev >= 8 ? 1 : 2 };
    for (int m = 0; m < 2; m++) {
        scan_cat(masks[m]);
        for (int i = 0; i < cat_n; i++)
            if (!scmp(cat_name[i], name)) { cat_active = 0; con_puts("SEARCHING FOR "); con_puts(name); con_nl(); start_entry(i, 0); return; }
    }
    err("FILE NOT FOUND");
}
static void b_save(void) {
    char name[40], rel[120];
    quoted_name(name, 40);
    P += sl(P);
    sanitize(name);
    if (!name[0]) { err("MISSING FILE NAME"); return; }
    if (!nprog) { err("NO PROGRAM"); return; }
    int n = program_to_text(loadbuf, (int)sizeof loadbuf, 1);
    con_puts("SAVING "); con_puts(name); con_nl();
    path_join(rel, "floppies", name); scat(rel, ".BAS");
    if (!plat_write(rel, loadbuf, n)) err("WRITE");
}

static void statement(void) {
    ws();
    if (kw("PRINT") || kw("?")) b_print();
    else if (kw("INPUT")) b_input();
    else if (kw("IF")) b_if();
    else if (kw("GOTO")) { int n = linenum(); if (!berr[0]) jumpto(n); }
    else if (kw("GOSUB")) { int n = linenum(); if (!berr[0]) b_gosub_to(n); }
    else if (kw("RETURN")) b_return();
    else if (kw("FOR")) b_for();
    else if (kw("NEXT")) b_next();
    else if (kw("GET")) b_get();
    else if (kw("DIM")) b_dim();
    else if (kw("ON")) b_on();
    else if (kw("END")) { brun = 0; ready(); }
    else if (kw("STOP")) b_stop(1);
    else if (kw("REM")) P += sl(P);
    else if (kw("CLS")) con_cls();
    else if (kw("CLR")) clear_vars();
    else if (kw("LOCATE")) b_locate();
    else if (kw("COLOR")) b_color();
    else if (kw("SLEEP")) { int n = (int)nexpr(); if (n > 0) bsleep_until = now_ms + (u32)n * 1000u / 60u; }
    else if (kw("LET")) b_let();
    else if (kw("POKE")) b_poke();
    else if (kw("SYS")) {
        int a = (int)nexpr();
        if (!berr[0] && a == 64738) { nprog = 0; clear_vars(); basic_screen_reset(); brun = 0; }
    }
    else if (kw("RUN")) b_run();
    else if (kw("LIST")) b_list();
    else if (kw("NEW")) { nprog = 0; clear_vars(); cat_active = 0; }
    else if (kw("HELP")) b_help();
    else if (kw("EDIT")) editor_from_program();
    else if (kw("LOAD")) b_load();
    else if (kw("SAVE")) b_save();
    else if (kw("DIR")) show_catalog(2);
    else if (kw("VERIFY")) { P += sl(P); con_puts("OK\n"); }
    else b_let();
}
static void basic_error(int ln) {
    if (ccolm) con_nl();
    con_puts("?"); con_puts(berr); con_puts("  ERROR");
    if (ln >= 0 && ln < nprog) { con_puts(" IN "); con_putn(prog[ln].num); }
    con_nl();
    brun = 0; bwait = 0;
    ready();
}
static void bstep(void) {
    if (!brun || bwait) return;
    ws();
    if (*P == ':') { P++; return; }
    if (*P == 0) {
        if (bline >= 0 && bline + 1 < nprog) { bline++; P = prog[bline].t; return; }
        brun = 0; ready(); return;
    }
    jumped = 0; berr[0] = 0;
    int ln = bline;
    statement();
    if (berr[0]) { basic_error(ln); return; }
    if (!brun || jumped || bwait) return;
    ws();
    if (*P && *P != ':') { err("SYNTAX"); basic_error(ln); }
}
static void basic_enter(const char *line) {
    const char *q = line;
    while (*q == ' ') q++;
    if (!*q) return;
    if (isdg(*q)) {
        int n = 0; while (isdg(*q)) n = n * 10 + *q++ - '0';
        while (*q == ' ') q++;
        storeline(n, q);
        return;
    }
    ncpy(bdirect, q, 80);
    bline = -1; P = bdirect; brun = 1; berr[0] = 0; bsleep_until = 0;
}
static void basic_command(const char *cmd) {       /* toolbar: type a command */
    if (brun) return;
    inlen = 0;
    if (ccolm) con_nl();
    con_puts(cmd); con_nl();
    basic_enter(cmd);
}
static void kq_push(int k) { int n = (kqt + 1) % 32; if (n != kqh) { kq[kqt] = k; kqt = n; } }
static void basic_key(int ch) {
    if (ch == 27 || ch == 3) { if (brun) b_stop(1); return; }
    if (brun && !bwait) { if (ch >= 'a' && ch <= 'z') ch -= 32; kq_push(ch); return; }
    if (ch == 8) {
        if (inlen > 0) {
            inlen--;
            if (ccolm > 0) ccolm--; else if (crow > 0) { crow--; ccolm = con_w - 1; }
            cch[crow][ccolm] = ' ';
        }
        return;
    }
    if (ch == 13) {
        inbuf[inlen] = 0; con_nl();
        if (bwait) {
            if (binlv.s) { ncpy(binlv.sp, inbuf, binlv.smax); bwait = 0; }
            else {
                const char *q = inbuf; int ok; double n = parsenum(&q, &ok);
                while (*q == ' ') q++;
                if (!ok || *q) con_puts("?REDO FROM START\n? ");
                else { *binlv.np = n; bwait = 0; }
            }
        } else basic_enter(inbuf);
        inlen = 0;
        return;
    }
    if (ch >= 'a' && ch <= 'z') ch -= 32;
    if (ch < 32 || ch > 126 || inlen >= 78) return;
    inbuf[inlen++] = (char)ch;
    con_putc(ch);
}

/* =====================================================================
   Text editor (used by notes, Game Maker and the help viewer)
   ===================================================================== */
enum { K_LEFT = 1000, K_RIGHT, K_UP, K_DOWN, K_HOME, K_END, K_PGUP, K_PGDN, K_DEL, K_F2 };
typedef struct { char *b; int len, cap, cur, top, dirty, wrap, upper, ro; u32 tedit; } TextEd;
#define MAXLAY 20000
static int L_s[MAXLAY], L_e[MAXLAY];
static int ted_layout(TextEd *t, int cols) {
    int n = 0, s = 0, i = 0;
    if (cols < 4) cols = 4;
    for (;;) {
        if (n >= MAXLAY - 1) { L_s[n] = s; L_e[n] = t->len; return n + 1; }
        if (t->wrap && i - s == cols && i < t->len && t->b[i] != '\n') {
            int sp = i - 1;
            while (sp > s && t->b[sp] != ' ') sp--;
            if (sp > s) { L_s[n] = s; L_e[n] = sp; n++; s = i = sp + 1; continue; }
            L_s[n] = s; L_e[n] = i; n++; s = i; continue;
        }
        if (i >= t->len || t->b[i] == '\n') {
            L_s[n] = s; L_e[n] = i; n++;
            if (i >= t->len) return n;
            i++; s = i; continue;
        }
        i++;
    }
}
static int ted_line_of(int cur, int n) { int l = 0; for (int i = 0; i < n; i++) if (L_s[i] <= cur) l = i; else break; return l; }
static void ted_insert(TextEd *t, int c) {
    if (t->len >= t->cap) return;
    mmove(t->b + t->cur + 1, t->b + t->cur, t->len - t->cur);
    t->b[t->cur++] = (char)c; t->len++; t->b[t->len] = 0;
    t->dirty = 1; t->tedit = now_ms;
}
static void ted_delete(TextEd *t, int at) {
    if (at < 0 || at >= t->len) return;
    mmove(t->b + at, t->b + at + 1, t->len - at - 1);
    t->len--; t->b[t->len] = 0;
    t->dirty = 1; t->tedit = now_ms;
}
static void ted_visible(TextEd *t, int cols, int rows) {
    int n = ted_layout(t, cols), l = ted_line_of(t->cur, n);
    if (rows < 1) rows = 1;
    if (l < t->top) t->top = l;
    if (l >= t->top + rows) t->top = l - rows + 1;
    if (t->top > n - 1) t->top = maxi(0, n - 1);
}
static void ted_key(TextEd *t, int k, int cols, int rows) {
    int n = ted_layout(t, cols), l = ted_line_of(t->cur, n), col = t->cur - L_s[l], nl = -1;
    switch (k) {
    case K_LEFT: if (t->cur > 0) t->cur--; break;
    case K_RIGHT: if (t->cur < t->len) t->cur++; break;
    case K_UP: nl = l - 1; break;
    case K_DOWN: nl = l + 1; break;
    case K_PGUP: nl = l - rows; break;
    case K_PGDN: nl = l + rows; break;
    case K_HOME: t->cur = L_s[l]; break;
    case K_END: t->cur = L_e[l]; break;
    case K_DEL: if (!t->ro) ted_delete(t, t->cur); break;
    case 8: if (!t->ro && t->cur > 0) { t->cur--; ted_delete(t, t->cur); } break;
    case 13: if (!t->ro) ted_insert(t, '\n'); break;
    case 9: if (!t->ro) { ted_insert(t, ' '); ted_insert(t, ' '); } break;
    default:
        if (!t->ro && k >= 32 && k <= 126) ted_insert(t, t->upper ? up(k) : k);
    }
    if (nl != -1) {
        if (nl < 0) nl = 0;
        if (nl > n - 1) nl = n - 1;
        t->cur = L_s[nl] + mini(col, L_e[nl] - L_s[nl]);
    }
    ted_visible(t, cols, rows);
}
static void ted_draw(TextEd *t, int x, int y, int w, int h, u32 fg, u32 bg, int focused) {
    int cols = (w - 8) / 8, rows = (h - 8) / 16;
    rect(x, y, w, h, bg);
    int n = ted_layout(t, cols);
    if (t->top > n - 1) t->top = maxi(0, n - 1);
    if (t->top < 0) t->top = 0;
    for (int l = t->top; l < n && l < t->top + rows; l++)
        textn(x + 4, y + 4 + (l - t->top) * 16, t->b + L_s[l], mini(L_e[l] - L_s[l], cols + 1), fg);
    if (focused && !t->ro && (now_ms / 400) % 2 == 0) {
        int cl = ted_line_of(t->cur, n), cc = t->cur - L_s[cl];
        if (cl >= t->top && cl < t->top + rows && cc <= cols) rect(x + 4 + cc * 8, y + 4 + (cl - t->top) * 16, 2, 16, fg);
    }
    if (n > rows && rows > 0) {                   /* scroll position marker */
        int bh = maxi(8, h * rows / n), by = y + (h - bh) * t->top / maxi(1, n - rows);
        rect(x + w - 4, y, 4, h, lerp(bg, fg, 1, 6));
        rect(x + w - 4, by, 4, bh, lerp(bg, fg, 1, 2));
    }
}
static void ted_click(TextEd *t, int rx, int ry, int w, int h) {
    int cols = (w - 8) / 8, rows = (h - 8) / 16;
    int n = ted_layout(t, cols), l = t->top + (ry - 4) / 16;
    (void)rows;
    if (l < 0) l = 0;
    if (l > n - 1) l = n - 1;
    int c = (rx - 4 + 4) / 8; if (c < 0) c = 0;
    t->cur = L_s[l] + mini(c, L_e[l] - L_s[l]);
}
static void ted_scroll(TextEd *t, int d, int w, int h) {
    int n = ted_layout(t, (w - 8) / 8), rows = (h - 8) / 16;
    t->top += d;
    if (t->top > n - rows) t->top = n - rows;
    if (t->top < 0) t->top = 0;
}
static void ted_set(TextEd *t, const char *s) {
    int k = 0;
    for (int i = 0; s[i] && k < t->cap; i++) if (s[i] != '\r') t->b[k++] = s[i];
    t->b[k] = 0; t->len = k; t->cur = 0; t->top = 0; t->dirty = 0;
}
static char savebuf[80000];
static int ted_save(TextEd *t, const char *rel) {
    int n = 0;
    for (int i = 0; i < t->len && n < (int)sizeof savebuf - 2; i++) {
        if (t->b[i] == '\n') savebuf[n++] = '\r';
        savebuf[n++] = t->b[i];
    }
    if (!plat_write(rel, savebuf, n)) return 0;
    t->dirty = 0;
    return 1;
}

/* =====================================================================
   Desktop, windows, menus
   ===================================================================== */
enum { T_BASIC, T_NOTE, T_CLOCK, T_ABOUT, T_SETTINGS, T_FOLDER, T_EDITOR, T_DIALOG, T_HELP };
typedef struct { int used, type, x, y, w, h, data; char title[64]; } Win;
#define MAXWIN 28
static Win win[MAXWIN];
static int zord[MAXWIN], nz, wincount;
#define MENUBAR 19
#define TOOLBAR 22
static int state;                   /* 0 boot, 1 desktop, 2 shutdown */
static u32 t0, tshut;
static int mx = 320, my = 200, last_cw = 640, last_ch = 400;
static int dragw = -1, dragmode, dragdx, dragdy;
static int fs_gen = 1;              /* bumps on every file change, views refresh */
static int desk_focus;              /* 1 after clicking the desktop: keys go to the icons */

/* ----- notes ----- */
#define MAXNOTE 12
#define NOTECAP 16000
static char notemem[MAXNOTE][NOTECAP + 1];
static TextEd notes[MAXNOTE];
static char notepath[MAXNOTE][220];
static int noteused[MAXNOTE];
/* ----- Game Maker editor ----- */
static char edmem[32001];
static TextEd ed = { edmem, 0, 32000, 0, 0, 0, 0, 1, 0, 0 };
static char edpath[220], ed_status[60];
static u32 ed_status_t;
static int ed_new_armed;
/* ----- help viewer ----- */
static char helpmem[6000];
static TextEd helped = { helpmem, 0, 5999, 0, 0, 0, 1, 0, 1, 0 };

static int win_cx(int i) { return win[i].x + 3; }
static int win_cy(int i) { return win[i].y + 21; }
static int win_cw(int i) { return win[i].w - 6; }
static int win_chh(int i) { return win[i].h - 24; }
static int resizable(int t) { return t == T_NOTE || t == T_FOLDER || t == T_EDITOR || t == T_HELP; }
static int top_win(void) { return nz ? zord[nz - 1] : -1; }
static int find_win(int type, int data) {
    for (int i = 0; i < MAXWIN; i++) if (win[i].used && win[i].type == type && (data < 0 || win[i].data == data)) return i;
    return -1;
}
static void focus(int a) {
    int j = 0;
    for (int i = 0; i < nz; i++) if (zord[i] != a) zord[j++] = zord[i];
    zord[j++] = a; nz = j; desk_focus = 0;
}
static void clamp_win(Win *w) {
    if (w->w > W) w->w = W;
    if (w->h > H - MENUBAR) w->h = H - MENUBAR;
    if (w->x > W - 60) w->x = W - 60;
    if (w->x < 40 - w->w) w->x = 40 - w->w;
    if (w->y > H - 24) w->y = H - 24;
    if (w->y < MENUBAR) w->y = MENUBAR;
}
static int open_win(int type, int data, const char *title, int cw, int ch) {
    int i;
    for (i = 0; i < MAXWIN; i++) if (!win[i].used) break;
    if (i == MAXWIN) return -1;
    Win *w = &win[i];
    w->used = 1; w->type = type; w->data = data; ncpy(w->title, title, 64);
    w->w = cw + 6; w->h = ch + 24;
    int k = wincount++ % 7;                          /* cascade, spread wider on big screens */
    int sx = maxi(26, mini(48, (W - w->w - 120) / 7)), sy = maxi(22, mini(36, (H - w->h - MENUBAR - 20) / 7));
    w->x = 120 + k * sx; w->y = MENUBAR + 14 + k * sy;
    if (w->x + w->w > W) w->x = maxi(0, W - w->w);
    if (w->y + w->h > H) w->y = maxi(MENUBAR, H - w->h);
    clamp_win(w);
    focus(i); desk_focus = 0;
    return i;
}
static void note_close(int n) {
    if (notes[n].dirty) ted_save(&notes[n], notepath[n]);
    noteused[n] = 0;
}
static void close_win(int a) {
    if (win[a].type == T_NOTE) note_close(win[a].data);
    win[a].used = 0;
    int j = 0; for (int i = 0; i < nz; i++) if (zord[i] != a) zord[j++] = zord[i];
    nz = j;
    if (dragw == a) dragw = -1;
}
static void basic_window_size(int *cw, int *ch) { *cw = con_w * 8 + 16; *ch = TOOLBAR + con_h * 16 + 16; }
static void open_basic_window(void) {
    int i = find_win(T_BASIC, -1);
    if (i >= 0) { focus(i); return; }
    int cw, ch; basic_window_size(&cw, &ch);
    i = open_win(T_BASIC, 0, "BASIC 7.0", cw, ch);
    if (i >= 0) { win[i].x = maxi(0, mini(176, W - win[i].w)); win[i].y = MENUBAR + 14; clamp_win(&win[i]); }
}
static void open_single(int type, const char *title, int cw, int ch) {
    int i = find_win(type, -1);
    if (i >= 0) { focus(i); return; }
    open_win(type, 0, title, cw, ch);
}
static void set_status(const char *s) { ncpy(ed_status, s, 60); ed_status_t = now_ms; }
static void editor_title(void) {
    int i = find_win(T_EDITOR, -1); if (i < 0) return;
    char t[64]; scpy(t, "Game Maker - ");
    if (edpath[0]) { char b[40]; ncpy(b, path_base(edpath), 40); scat(t, b); } else scat(t, "untitled");
    if (ed.dirty) scat(t, " *");
    ncpy(win[i].title, t, 64);
}
static void open_editor(void) {
    int i = find_win(T_EDITOR, -1);
    if (i < 0) i = open_win(T_EDITOR, 0, "Game Maker", mini(W - 40, 600), mini(H - MENUBAR - 40, 380));
    else focus(i);
    editor_title();
}
static void editor_from_program(void) {
    int n = program_to_text(edmem, 32000, 0);
    ed.len = n; ed.cur = 0; ed.top = 0; ed.dirty = 1;
    open_editor();
    set_status("Program copied from BASIC");
}
static const char *HELP_TEXT =
"GAME MAKER - QUICK REFERENCE\n"
"\n"
"Write a program with line numbers, then press Run. Save puts it in the floppies folder, "
"so LOAD\"$\",8 lists it in BASIC. Ctrl+S saves. Errors show in the BASIC window with the line number.\n"
"\n"
"SCREEN\n"
"  CLS               clear the screen\n"
"  LOCATE R,C        move the cursor (0,0 = top left)\n"
"  PRINT X;\"TEXT\";   print, ; keeps the cursor on the line\n"
"  COLOR F[,B[,BD]]  text, background, border colour 0-15\n"
"  SCRN(R,C)         character code at row R, column C\n"
"  PEEK/POKE 1024+R*W+C  screen memory (W = screen width)\n"
"  CHR$(160) block   CHR$(209) ball   CHR$(205)/(206) diagonals\n"
"\n"
"KEYS AND TIMING\n"
"  GET K$            read a key without waiting (\"\" if none)\n"
"  arrows: LEFT=CHR$(157) RIGHT=CHR$(29) UP=CHR$(145) DOWN=CHR$(17)\n"
"  SLEEP N           wait N/60 of a second (keeps the game smooth)\n"
"  TI                time in 1/60 seconds, RND(1) random 0..1\n"
"\n"
"PROGRAM FLOW\n"
"  IF A>B THEN 100   IF ... THEN statement\n"
"  FOR I=1 TO 10 STEP 2 ... NEXT\n"
"  GOSUB 500 / RETURN   ON X GOTO 10,20,30\n"
"  DIM A(50), B$(10), G(20,20)   arrays\n"
"  END, STOP, REM comment\n"
"\n"
"COLOURS\n"
"  0 black 1 white 2 red 3 cyan 4 purple 5 green 6 blue 7 yellow\n"
"  8 orange 9 brown 10 pink 11 dark grey 12 grey 13 light green\n"
"  14 light blue 15 light grey\n"
"\n"
"Press Example to load DODGE, a small complete game to learn from.\n";
static const char *EXAMPLE_GAME =
"10 REM DODGE! LEFT/RIGHT ARROWS OR A/D. ESC = QUIT\n"
"20 CLS:POKE 53281,0:X=20:S=0:T=0:DIM R(9),C(9)\n"
"30 FOR I=0 TO 9:R(I)=-1:NEXT\n"
"40 COLOR 11:FOR I=0 TO 39:LOCATE 17,I:PRINT CHR$(160);:NEXT\n"
"50 COLOR 7:LOCATE 0,0:PRINT \"DODGE!  SCORE\";S;\"   \";\n"
"60 GET K$\n"
"70 LOCATE 16,X:PRINT \" \";\n"
"80 IF K$=CHR$(157) OR K$=\"A\" THEN IF X>0 THEN X=X-1\n"
"90 IF K$=CHR$(29) OR K$=\"D\" THEN IF X<39 THEN X=X+1\n"
"100 COLOR 5:LOCATE 16,X:PRINT CHR$(209);\n"
"110 T=T+1:IF T<4 THEN 190\n"
"120 T=0\n"
"130 FOR I=0 TO 9\n"
"140 IF R(I)<0 THEN IF RND(1)<0.15 THEN R(I)=1:C(I)=INT(RND(1)*40):GOTO 180\n"
"150 IF R(I)<0 THEN 180\n"
"160 LOCATE R(I),C(I):PRINT \" \";:R(I)=R(I)+1\n"
"170 IF R(I)=16 THEN IF C(I)=X THEN 300\n"
"172 IF R(I)=17 THEN R(I)=-1:S=S+1:GOTO 180\n"
"175 COLOR 2:LOCATE R(I),C(I):PRINT \"*\";\n"
"180 NEXT\n"
"190 SLEEP 1:GOTO 50\n"
"300 COLOR 2:LOCATE 8,15:PRINT \"GAME OVER!\"\n"
"310 COLOR 1:LOCATE 10,15:PRINT \"SCORE:\";S\n"
"320 LOCATE 12,9:PRINT \"PRESS RETURN TO PLAY\"\n"
"330 GET K$:IF K$<>CHR$(13) THEN 330\n"
"340 GOTO 20\n";

static void open_help(void) {
    int i = find_win(T_HELP, -1);
    if (i >= 0) { focus(i); return; }
    ted_set(&helped, HELP_TEXT);
    open_win(T_HELP, 0, "Game Maker Help", mini(W - 40, 560), mini(H - MENUBAR - 30, 360));
}
static void editor_open_file(const char *rel) {
    int n = plat_read(rel, loadbuf, (int)sizeof loadbuf - 1);
    if (n < 0) { open_editor(); set_status("Could not open the file"); return; }
    loadbuf[n] = 0;
    ted_set(&ed, loadbuf);
    ncpy(edpath, rel, 220);
    open_editor();
    set_status("Opened");
}
static void editor_run(void) {
    if (ed.len >= (int)sizeof loadbuf) return;
    for (int i = 0; i <= ed.len; i++) loadbuf[i] = edmem[i];
    if (brun) b_stop(1);
    int skipped, n = parse_program(loadbuf, &skipped);
    open_basic_window();
    if (ccolm) con_nl();
    if (!n) { con_puts("?NO PROGRAM  ERROR\n"); ready(); set_status("Nothing to run: lines need numbers"); return; }
    if (skipped) { con_puts("SKIPPED "); con_putn(skipped); con_puts(" LINE(S) WITHOUT A NUMBER\n"); }
    con_puts("RUN\n");
    clear_vars();
    bline = 0; P = prog[0].t; brun = 1; berr[0] = 0; bsleep_until = 0; jumped = 0;
    set_status("Running in the BASIC window");
}

/* ----- dialog (name entry) ----- */
enum { DLG_NEWFOLDER, DLG_RENAME, DLG_SAVEPRG, DLG_EMPTY, DLG_DELETE };
static struct { int act; char prompt[60], prompt2[60]; char buf[48]; int len; char target[220]; char dir[220]; char ext[8]; } dlg;
static int dlg_confirm(void) { return dlg.act == DLG_EMPTY || dlg.act == DLG_DELETE; }
static void open_dialog(int act, const char *prompt, const char *initial, const char *title) {
    int i = find_win(T_DIALOG, -1);
    if (i >= 0) close_win(i);
    dlg.act = act; ncpy(dlg.prompt, prompt, 60); dlg.prompt2[0] = 0; ncpy(dlg.buf, initial, 48); dlg.len = sl(dlg.buf);
    i = open_win(T_DIALOG, 0, title, 336, 96);
    if (i >= 0) { win[i].x = (W - win[i].w) / 2; win[i].y = (H - win[i].h) / 2; }
}
static int path_under(const char *p, const char *root) {   /* p is root or inside it */
    int l = sl(root);
    for (int k = 0; k < l; k++) if (p[k] != root[k]) return 0;
    return p[l] == 0 || p[l] == '/';
}
static void note_paths_moved(const char *from, const char *to) {   /* keep open windows pointing at moved files */
    int lf = sl(from);
    for (int n = 0; n < MAXNOTE; n++) {
        if (!noteused[n] || !path_under(notepath[n], from)) continue;
        char t[260]; scpy(t, to); scat(t, notepath[n] + lf); ncpy(notepath[n], t, 220);
        int w = find_win(T_NOTE, n);
        if (w >= 0) { char tt[64]; ncpy(tt, path_base(notepath[n]), 64); if (has_ext(tt, "txt")) tt[sl(tt) - 4] = 0; ncpy(win[w].title, tt, 64); }
    }
    if (edpath[0] && path_under(edpath, from)) { char t[260]; scpy(t, to); scat(t, edpath + lf); ncpy(edpath, t, 220); editor_title(); }
}
static void views_paths_moved(const char *from, const char *to);
static void pos_rename(const char *dir, const char *oldn, const char *newn);
static void forget_paths(const char *rel);
static void empty_trash(void);
static void dlg_done(void) { fs_gen++; close_win(find_win(T_DIALOG, -1)); }
static void dlg_ok(void) {
    char name[60], rel[260];
    if (dlg_confirm()) {
        if (dlg.act == DLG_EMPTY) empty_trash();
        else { forget_paths(dlg.target); plat_delete(dlg.target); }
        dlg_done();
        return;
    }
    ncpy(name, dlg.buf, 48); sanitize(name);
    if (!name[0]) { scpy(dlg.prompt, "Please type a name:"); return; }
    if (dlg.act == DLG_NEWFOLDER) {
        path_join(rel, dlg.dir, name);
        if (plat_exists(rel)) { scpy(dlg.prompt, "That name is taken. Try another:"); return; }
        plat_mkdir(rel);
    } else if (dlg.act == DLG_RENAME) {
        scat(name, dlg.ext);
        path_join(rel, dlg.dir, name);
        if (!scmp(rel, dlg.target)) { close_win(find_win(T_DIALOG, -1)); return; }
        if (plat_exists(rel) && scmpi(rel, dlg.target)) { scpy(dlg.prompt, "That name is taken. Try another:"); return; }
        for (int n = 0; n < MAXNOTE; n++) if (noteused[n] && path_under(notepath[n], dlg.target) && notes[n].dirty) ted_save(&notes[n], notepath[n]);
        if (!plat_move(dlg.target, rel)) { scpy(dlg.prompt, "Could not rename. Try another name:"); return; }
        note_paths_moved(dlg.target, rel);
        views_paths_moved(dlg.target, rel);
        pos_rename(dlg.dir, path_base(dlg.target), name);
    } else {
        path_join(rel, "floppies", name);
        if (!has_ext(name, "bas")) scat(rel, ".BAS");
        if (!ted_save(&ed, rel)) { scpy(dlg.prompt, "Could not save. Try another name:"); return; }
        ncpy(edpath, rel, 220);
        editor_title();
        set_status("Saved to the floppies folder");
    }
    dlg_done();
}
static void dlg_char(int ch) {
    if (ch == 27) { close_win(find_win(T_DIALOG, -1)); return; }
    if (ch == 13) { dlg_ok(); return; }
    if (dlg_confirm()) return;
    if (ch == 8) { if (dlg.len) dlg.buf[--dlg.len] = 0; return; }
    if (ch >= 32 && ch <= 126 && dlg.len < 40) { dlg.buf[dlg.len++] = (char)ch; dlg.buf[dlg.len] = 0; }
}
static void editor_save(int as) {
    if (!as && edpath[0]) {
        if (ted_save(&ed, edpath)) set_status("Saved"); else set_status("Could not save");
        fs_gen++; editor_title();
        return;
    }
    char init[48] = "MYGAME";
    if (edpath[0]) { ncpy(init, path_base(edpath), 48); if (has_ext(init, "bas")) init[sl(init) - 4] = 0; }
    open_dialog(DLG_SAVEPRG, "Save program as (goes in floppies):", init, "Save Program");
}

/* ----- views: the desktop and folder windows ----- */
#define MAXITEMS 96
#define MAXVIEW 14
typedef struct { int used, n, gen; u32 stamp; char path[220]; char name[MAXITEMS][64]; char isdir[MAXITEMS]; } View;
static View views[MAXVIEW];
#define NB 5
static const char *BI_LABEL[NB] = { "BASIC 7.0", "Game Maker", "Clock", "Settings", "About" };
static const int BI_ICON[NB] = { IC_BASIC, IC_JOY, IC_CLOCK, IC_GEAR, IC_DISK };
static int sel_win = -2, sel_idx = -1, last_click_win = -3, last_click_idx = -1;
static u32 last_click;

static void view_cb(const char *name, int isdir, void *ctx) {
    View *v = (View *)ctx;
    if (v->n >= MAXITEMS || name[0] == '.' || sl(name) > 62) return;
    ncpy(v->name[v->n], name, 64); v->isdir[v->n] = (char)isdir; v->n++;
}
static void view_refresh(View *v) {
    v->n = 0;
    plat_dir(v->path, view_cb, v);
    for (int i = 1; i < v->n; i++)                       /* folders first, then by name */
        for (int j = i; j > 0; j--) {
            int a = j - 1, b = j;
            int gt = v->isdir[a] != v->isdir[b] ? v->isdir[b] > v->isdir[a] : scmpi(v->name[a], v->name[b]) > 0;
            if (!gt) break;
            char t[64]; scpy(t, v->name[a]); scpy(v->name[a], v->name[b]); scpy(v->name[b], t);
            char d = v->isdir[a]; v->isdir[a] = v->isdir[b]; v->isdir[b] = d;
        }
    v->gen = fs_gen; v->stamp = now_ms;
}
static View *view_get(int vi) {
    View *v = &views[vi];
    if (v->gen != fs_gen || now_ms - v->stamp > 3000) view_refresh(v);
    return v;
}
static void views_paths_moved(const char *from, const char *to) {
    int lf = sl(from);
    for (int i = 1; i < MAXVIEW; i++) {
        if (!views[i].used || !path_under(views[i].path, from)) continue;
        char t[260]; scpy(t, to); scat(t, views[i].path + lf); ncpy(views[i].path, t, 220);
        for (int w = 0; w < MAXWIN; w++) if (win[w].used && win[w].type == T_FOLDER && win[w].data == i) ncpy(win[w].title, path_base(views[i].path), 64);
    }
}
static int view_count(int vi) { return (vi == 0 ? NB : 0) + view_get(vi)->n; }
static void item_info(int vi, int idx, char *label, int *ic, int maxc) {
    if (vi == 0 && idx < NB) { fit_label(BI_LABEL[idx], maxc, label); *ic = BI_ICON[idx]; return; }
    View *v = &views[vi];
    int j = idx - (vi == 0 ? NB : 0);
    char nm[64]; scpy(nm, v->name[j]);
    if (v->isdir[j]) *ic = (vi == 0 && !scmpi(nm, "Trash")) ? IC_TRASH : IC_FOLDER;
    else if (has_ext(nm, "txt")) { *ic = IC_NOTE; nm[sl(nm) - 4] = 0; }
    else if (has_ext(nm, "bas")) *ic = IC_PROG;
    else if (known_ext(ext_of(nm))) *ic = IC_DISK;
    else *ic = IC_PROG;
    fit_label(nm, maxc, label);
}
static int item_rel(int vi, int idx, char *out) {   /* 0 for built-ins */
    if (vi == 0 && idx < NB) return 0;
    int j = idx - (vi == 0 ? NB : 0);
    path_join(out, views[vi].path, views[vi].name[j]);
    return 1 + views[vi].isdir[j];                 /* 1 file, 2 folder */
}
static void item_key(int vi, int idx, char *out) {  /* name used to remember an icon's position */
    if (vi == 0 && idx < NB) { out[0] = '*'; out[1] = (char)('0' + idx); out[2] = 0; return; }
    scpy(out, views[vi].name[idx - (vi == 0 ? NB : 0)]);
}

/* ----- remembered icon positions: one hidden ".positions" file per folder ----- */
#define MAXPOS 16
#define PMAX (MAXITEMS + NB)
typedef struct { int used; u32 age; char dir[220]; int n; char name[PMAX][64]; short x[PMAX], y[PMAX]; } PosMap;
static PosMap posm[MAXPOS];
static u32 pos_clock;
static void pos_file(const char *dir, char *out) { path_join(out, dir, ".positions"); }
static void pos_save(PosMap *m) {
    int k = 0;
    for (int i = 0; i < m->n && k < (int)sizeof savebuf - 100; i++) {
        putint_s(savebuf + k, m->x[i]); k += sl(savebuf + k); savebuf[k++] = ' ';
        putint_s(savebuf + k, m->y[i]); k += sl(savebuf + k); savebuf[k++] = ' ';
        scpy(savebuf + k, m->name[i]); k += sl(m->name[i]);
        savebuf[k++] = '\r'; savebuf[k++] = '\n';
    }
    char f[260]; pos_file(m->dir, f);
    plat_write(f, savebuf, k);
}
static PosMap *pos_get(const char *dir) {
    int old = 0;
    for (int i = 0; i < MAXPOS; i++) {
        if (posm[i].used && !scmp(posm[i].dir, dir)) { posm[i].age = ++pos_clock; return &posm[i]; }
        if (!posm[i].used || posm[i].age < posm[old].age) old = i;
        if (!posm[i].used) { old = i; break; }
    }
    PosMap *m = &posm[old];
    m->used = 1; m->age = ++pos_clock; m->n = 0; ncpy(m->dir, dir, 220);
    char f[260]; pos_file(dir, f);
    int n = plat_read(f, loadbuf, (int)sizeof loadbuf - 1);
    if (n > 0) {
        loadbuf[n] = 0;
        for (char *p = loadbuf; *p && m->n < PMAX;) {
            char *e = p; while (*e && *e != '\n') e++;
            char hold = *e; *e = 0;
            if (e > p && e[-1] == '\r') e[-1] = 0;
            int x = atoi_(p); while (*p && *p != ' ') p++; while (*p == ' ') p++;
            int y = atoi_(p); while (*p && *p != ' ') p++; if (*p == ' ') p++;
            if (*p) { ncpy(m->name[m->n], p, 64); m->x[m->n] = (short)x; m->y[m->n] = (short)y; m->n++; }
            *e = hold; p = *e ? e + 1 : e;
        }
    }
    return m;
}
static int pos_find(PosMap *m, const char *name) { for (int i = 0; i < m->n; i++) if (!scmp(m->name[i], name)) return i; return -1; }
static void pos_put(PosMap *m, const char *name, int x, int y) {
    int i = pos_find(m, name);
    if (i < 0) { if (m->n >= PMAX) return; i = m->n++; ncpy(m->name[i], name, 64); }
    m->x[i] = (short)maxi(0, x); m->y[i] = (short)maxi(0, y);
}
static void pos_set(const char *dir, const char *name, int x, int y) { PosMap *m = pos_get(dir); pos_put(m, name, x, y); pos_save(m); }
static void pos_del(const char *dir, const char *name) {
    PosMap *m = pos_get(dir);
    int i = pos_find(m, name); if (i < 0) return;
    m->n--; for (int j = i; j < m->n; j++) { scpy(m->name[j], m->name[j + 1]); m->x[j] = m->x[j + 1]; m->y[j] = m->y[j + 1]; }
    pos_save(m);
}
static void pos_rename(const char *dir, const char *oldn, const char *newn) {
    PosMap *m = pos_get(dir);
    int i = pos_find(m, oldn); if (i < 0) return;
    ncpy(m->name[i], newn, 64); pos_save(m);
}
static void pos_clear(const char *dir) { PosMap *m = pos_get(dir); m->n = 0; pos_save(m); }

/* ----- laying out a view: remembered spots first, then the free grid cells ----- */
static int LX[PMAX], LY[PMAX];
static int cell_w(void) { return S.icons ? 84 : 156; }
static int cell_h(void) { return S.icons ? 70 : 22; }
static void item_cell(int desk, int rx, int ry, int rw, int rh, int i, int *x, int *y) {
    int cwid = cell_w(), chei = cell_h();
    if (desk) { int per = maxi(1, (rh - 8) / chei); *x = rx + 8 + (i / per) * cwid; *y = ry + 8 + (i % per) * chei; }
    else { int per = maxi(1, (rw - 8) / cwid); *x = rx + 8 + (i % per) * cwid; *y = ry + 6 + (i / per) * chei; }
}
static int view_layout(int vi, int rx, int ry, int rw, int rh, int desk) {
    int n = view_count(vi), cw = cell_w(), ch = cell_h();
    if (n > PMAX) n = PMAX;
    PosMap *m = pos_get(views[vi].path);
    char placed[PMAX];
    for (int i = 0; i < n; i++) {
        char key[64]; item_key(vi, i, key);
        int k = pos_find(m, key);
        placed[i] = k >= 0;
        if (k >= 0) {
            LX[i] = rx + mini(m->x[k], maxi(0, rw - cw));
            LY[i] = ry + mini(m->y[k], maxi(0, rh - ch));
        }
    }
    int cell = 0;
    for (int i = 0; i < n; i++) {
        if (placed[i]) continue;
        for (;; cell++) {
            int x, y; item_cell(desk, rx, ry, rw, rh, cell, &x, &y);
            int ok = 1;
            if (cell < 3000)
                for (int j = 0; j < n && ok; j++)
                    if (placed[j] && LX[j] > x - cw + 6 && LX[j] < x + cw - 6 && LY[j] > y - ch + 6 && LY[j] < y + ch - 6) ok = 0;
            if (ok) { LX[i] = x; LY[i] = y; placed[i] = 1; cell++; break; }
        }
    }
    return n;
}

/* ----- dragging icons ----- */
static int idrag, idrag_win, idrag_idx, idrag_sx, idrag_sy, idrag_ox, idrag_oy;

static void draw_item(int x, int y, const char *lab, int ic, int sel, int desk) {
    u32 fg = desk ? 0xFFFFFF : 0x000000;
    if (S.icons) {
        icon(x + (84 - 32) / 2, y + 2, ic, 2);
        int lx = x + (84 - sl(lab) * 8) / 2, ly = y + 36;
        if (sel) { rect(lx - 2, ly, sl(lab) * 8 + 4, 16, TH.sel); text(lx, ly, lab, 0xFFFFFF); }
        else { if (desk) text(lx + 1, ly + 1, lab, 0x000000); text(lx, ly, lab, fg); }
    } else {
        icon(x + 2, y + 3, ic, 1);
        int lx = x + 22, ly = y + 3;
        if (sel) { rect(lx - 2, ly, sl(lab) * 8 + 4, 16, TH.sel); text(lx, ly, lab, 0xFFFFFF); }
        else { if (desk) text(lx + 1, ly + 1, lab, 0x000000); text(lx, ly, lab, fg); }
    }
}
static void draw_view(int vi, int wid, int rx, int ry, int rw, int rh, int desk) {
    int n = view_layout(vi, rx, ry, rw, rh, desk);
    for (int i = 0; i < n; i++) {
        if (idrag == 2 && idrag_win == wid && idrag_idx == i) continue;   /* it is following the pointer */
        if (LX[i] > rx + rw || LY[i] > ry + rh) continue;
        char lab[40]; int ic;
        item_info(vi, i, lab, &ic, S.icons ? 10 : 17);
        draw_item(LX[i], LY[i], lab, ic, sel_win == wid && sel_idx == i, desk);
    }
    if (!desk && !view_get(vi)->n) text(rx + 10, ry + 10, "Empty. Right-click for New Note / Folder.", 0x707070);
}
static int view_hit(int vi, int rx, int ry, int rw, int rh, int desk, int x, int y) {
    int n = view_layout(vi, rx, ry, rw, rh, desk), cw = cell_w(), ch = cell_h();
    for (int i = n - 1; i >= 0; i--)
        if (x >= LX[i] && x < LX[i] + cw - 4 && y >= LY[i] && y < LY[i] + ch - 2) return i;
    return -1;
}
static int desk_rect_h(void) { return H - MENUBAR - 22; }
static void pos_freeze(int vi, int rx, int ry, int rw, int rh, int desk) {   /* pin every icon where it is now */
    int n = view_layout(vi, rx, ry, rw, rh, desk);
    PosMap *m = pos_get(views[vi].path);
    for (int i = 0; i < n; i++) { char key[64]; item_key(vi, i, key); if (pos_find(m, key) < 0) pos_put(m, key, LX[i] - rx, LY[i] - ry); }
    pos_save(m);
}
static void begin_icon_drag(int wid, int idx, int x, int y) {
    idrag = 1; idrag_win = wid; idrag_idx = idx; idrag_sx = x; idrag_sy = y;
    idrag_ox = x - LX[idx]; idrag_oy = y - LY[idx];       /* LX/LY are fresh from the hit test */
}

static int open_note(const char *rel) {
    for (int i = 0; i < MAXNOTE; i++)
        if (noteused[i] && !scmp(notepath[i], rel)) { int w = find_win(T_NOTE, i); if (w >= 0) focus(w); return i; }
    int i; for (i = 0; i < MAXNOTE; i++) if (!noteused[i]) break;
    if (i == MAXNOTE) return -1;
    int n = plat_read(rel, loadbuf, (int)sizeof loadbuf - 1); if (n < 0) n = 0;
    loadbuf[n] = 0;
    TextEd *t = &notes[i];
    t->b = notemem[i]; t->cap = NOTECAP; t->wrap = 1; t->upper = 0; t->ro = 0;
    ted_set(t, loadbuf); t->cur = t->len;
    noteused[i] = 1; ncpy(notepath[i], rel, 220);
    char title[64]; ncpy(title, path_base(rel), 64); if (has_ext(title, "txt")) title[sl(title) - 4] = 0;
    int w = open_win(T_NOTE, i, title, mini(W - 40, 380), mini(H - MENUBAR - 40, 240));
    if (w >= 0) ted_visible(t, (win_cw(w) - 8) / 8, (win_chh(w) - 8) / 16);
    return i;
}
static void open_folder(const char *rel) {
    for (int w = 0; w < MAXWIN; w++)
        if (win[w].used && win[w].type == T_FOLDER && !scmp(views[win[w].data].path, rel)) { focus(w); return; }
    int vi; for (vi = 1; vi < MAXVIEW; vi++) if (!views[vi].used) break;
    if (vi == MAXVIEW) return;
    views[vi].used = 1; ncpy(views[vi].path, rel, 220); views[vi].gen = 0;
    int w = open_win(T_FOLDER, vi, path_base(rel), mini(W - 40, 420), mini(H - MENUBAR - 40, 230));
    if (w < 0) views[vi].used = 0;
}
static void app_open(int bi) {
    if (bi == 0) open_basic_window();
    else if (bi == 1) open_editor();
    else if (bi == 2) open_single(T_CLOCK, "Clock", 208, 72);
    else if (bi == 3) open_single(T_SETTINGS, "Settings", 404, 196);
    else open_single(T_ABOUT, "About Commodore 98", 360, 160);
}
static void open_item(int vi, int idx) {
    char rel[260];
    int k = item_rel(vi, idx, rel);
    if (!k) { app_open(idx); return; }
    if (k == 2) { open_folder(rel); return; }
    if (has_ext(rel, "txt")) { if (open_note(rel) < 0) { open_basic_window(); con_puts("?TOO MANY NOTES OPEN  ERROR\n"); } return; }
    if (has_ext(rel, "bas")) { editor_open_file(rel); return; }
    if (known_ext(ext_of(rel)) && plat_emulate(rel)) return;
    plat_shell(rel);
}
static const char *view_dir(int wid) { return wid < 0 ? "desktop" : views[win[wid].data].path; }
static void new_note(const char *dir) {
    char name[80], rel[260];
    uniq_name(dir, "Note", ".txt", name);
    path_join(rel, dir, name);
    plat_write(rel, "", 0);
    fs_gen++;
    open_note(rel);
}
static int move_item(const char *rel, const char *destdir, char *out) {
    char parent[260], name[80], to[260];
    path_parent(rel, parent);
    if (!scmp(parent, destdir) || path_under(destdir, rel)) return 0;   /* same place, or into itself */
    char base[64]; ncpy(base, path_base(rel), 64);
    const char *e = ext_of(base);
    char ext[16] = ""; if (*e) { scpy(ext, "."); scat(ext, e); base[sl(base) - sl(e) - 1] = 0; }
    uniq_name(destdir, base, ext, name);
    path_join(to, destdir, name);
    for (int n = 0; n < MAXNOTE; n++) if (noteused[n] && path_under(notepath[n], rel) && notes[n].dirty) ted_save(&notes[n], notepath[n]);
    if (!plat_move(rel, to)) return 0;
    note_paths_moved(rel, to);
    views_paths_moved(rel, to);
    pos_del(parent, path_base(rel));
    fs_gen++;
    if (out) scpy(out, to);
    return 1;
}
static void move_to_trash(const char *rel) {
    if (!plat_exists("desktop/Trash")) plat_mkdir("desktop/Trash");
    move_item(rel, "desktop/Trash", 0);
}
static int in_trash(const char *rel) { return path_under(rel, "desktop/Trash") && scmp(rel, "desktop/Trash"); }
static void forget_paths(const char *rel) {        /* close everything that shows a file we are about to delete */
    for (int n = 0; n < MAXNOTE; n++)
        if (noteused[n] && path_under(notepath[n], rel)) {
            notes[n].dirty = 0;
            int w = find_win(T_NOTE, n); if (w >= 0) close_win(w); else noteused[n] = 0;
        }
    for (int w = 0; w < MAXWIN; w++)
        if (win[w].used && win[w].type == T_FOLDER && path_under(views[win[w].data].path, rel)) { views[win[w].data].used = 0; close_win(w); }
    if (edpath[0] && path_under(edpath, rel)) { edpath[0] = 0; ed.dirty = 1; editor_title(); }
    char parent[260]; path_parent(rel, parent); pos_del(parent, path_base(rel));
}
static char trash_names[MAXITEMS][64];
static int trash_n;
static void trash_cb(const char *name, int isdir, void *ctx) { (void)isdir; (void)ctx; if (trash_n < MAXITEMS && name[0] != '.') ncpy(trash_names[trash_n++], name, 64); }
static void empty_trash(void) {
    trash_n = 0;
    plat_dir("desktop/Trash", trash_cb, 0);
    for (int i = 0; i < trash_n; i++) {
        char rel[260]; path_join(rel, "desktop/Trash", trash_names[i]);
        forget_paths(rel); plat_delete(rel);
    }
    pos_clear("desktop/Trash");
    fs_gen++;
}

/* ----- popup menus (menu bar and right-click) ----- */
enum { A_NONE, A_ABOUT, A_SETTINGS, A_SHUTDOWN, A_BASIC, A_EDITOR, A_CLOCK, A_NEWNOTE, A_NEWFOLDER, A_EXPLORE,
       A_OPEN, A_RENAME, A_TRASH, A_REFRESH, A_EMPTY, A_DELPERM, A_TODESK, A_CLEANUP, A_OPENPRG = 100 };
static struct { int open, bar, x, y, n, w, ctxwin, ctxidx; char lab[16][44]; int act[16]; } pop;
static char prg_list[16][220];
static const char *BAR_T[3] = { "Commodore 98", "File", "Programs" };
static const int BAR_X[3] = { 4, 116, 166 }, BAR_W[3] = { 108, 48, 80 };
static void pop_begin(int x, int y, int bar, int cw, int ci) { pop.open = 1; pop.bar = bar; pop.x = x; pop.y = y; pop.n = 0; pop.w = 120; pop.ctxwin = cw; pop.ctxidx = ci; }
static void pop_add(const char *l, int a) {
    if (pop.n >= 16) return;
    ncpy(pop.lab[pop.n], l, 44); pop.act[pop.n++] = a;
    pop.w = maxi(pop.w, sl(l) * 8 + 28);
}
static void pop_fit(void) {
    if (pop.x + pop.w > W) pop.x = maxi(0, W - pop.w);
    if (pop.y + pop.n * 18 + 6 > H) pop.y = maxi(MENUBAR, H - pop.n * 18 - 6);
}
static void open_bar_menu(int b) {
    pop_begin(BAR_X[b], MENUBAR - 1, b, -2, -1);
    if (b == 0) { pop_add("About Commodore 98", A_ABOUT); pop_add("Settings", A_SETTINGS); pop_add("Shut Down...", A_SHUTDOWN); }
    if (b == 1) { pop_add("New Note", A_NEWNOTE); pop_add("New Folder", A_NEWFOLDER); pop_add("Show Desktop Folder", A_EXPLORE); }
    if (b == 2) { pop_add("BASIC 7.0", A_BASIC); pop_add("Game Maker", A_EDITOR); pop_add("Clock", A_CLOCK); }
    pop.w = maxi(pop.w, 176);
}
static int pop_item_at(int x, int y) {
    if (!pop.open || x < pop.x || x >= pop.x + pop.w || y < pop.y + 3) return -1;
    int i = (y - pop.y - 3) / 18;
    return i < pop.n ? i : -1;
}
static void do_action(int a) {
    int cw = pop.ctxwin, ci = pop.ctxidx;
    int vi = cw >= 0 && cw < MAXWIN && win[cw].used && win[cw].type == T_FOLDER ? win[cw].data : 0;
    const char *dir = cw >= 0 && vi ? views[vi].path : "desktop";
    char rel[260];
    switch (a) {
    case A_ABOUT: app_open(4); break;
    case A_SETTINGS: app_open(3); break;
    case A_SHUTDOWN: state = 2; tshut = now_ms; break;
    case A_BASIC: app_open(0); break;
    case A_EDITOR: app_open(1); break;
    case A_CLOCK: app_open(2); break;
    case A_NEWNOTE: new_note(dir); break;
    case A_NEWFOLDER: {
        char name[80]; uniq_name(dir, "New Folder", "", name);
        open_dialog(DLG_NEWFOLDER, "Name for the new folder:", name, "New Folder");
        ncpy(dlg.dir, dir, 220);
        break;
    }
    case A_EXPLORE: plat_shell("desktop"); break;
    case A_REFRESH: fs_gen++; break;
    case A_OPEN: if (ci >= 0) open_item(vi, ci); break;
    case A_RENAME:
        if (ci >= 0 && item_rel(vi, ci, rel)) {
            char nm[64]; ncpy(nm, path_base(rel), 64);
            dlg.ext[0] = 0;
            if (has_ext(nm, "txt")) { scpy(dlg.ext, ".txt"); nm[sl(nm) - 4] = 0; }
            open_dialog(DLG_RENAME, "New name:", nm, "Rename");
            ncpy(dlg.target, rel, 220); path_parent(rel, dlg.dir);
        }
        break;
    case A_TRASH: if (ci >= 0 && item_rel(vi, ci, rel)) move_to_trash(rel); sel_idx = -1; break;
    case A_TODESK: if (ci >= 0 && item_rel(vi, ci, rel)) move_item(rel, "desktop", 0); sel_idx = -1; break;
    case A_CLEANUP: pos_clear(dir); break;
    case A_EMPTY:
        open_dialog(DLG_EMPTY, "Empty the Trash?", "", "Empty Trash");
        scpy(dlg.prompt2, "This can't be undone.");
        break;
    case A_DELPERM:
        if (ci >= 0 && item_rel(vi, ci, rel)) {
            char nm[40], q[60]; fit_label(path_base(rel), 24, nm);
            scpy(q, "Delete "); scat(q, nm); scat(q, "?");
            open_dialog(DLG_DELETE, q, "", "Delete");
            scpy(dlg.prompt2, "This can't be undone.");
            ncpy(dlg.target, rel, 220);
        }
        sel_idx = -1;
        break;
    default:
        if (a >= A_OPENPRG && a < A_OPENPRG + 16) editor_open_file(prg_list[a - A_OPENPRG]);
    }
}
static void open_context(int wid, int idx, int x, int y) {
    pop_begin(x, y, -1, wid, idx);
    int vi = wid >= 0 ? win[wid].data : 0;
    if (idx >= 0) {
        pop_add("Open", A_OPEN);
        char rel[260];
        if (item_rel(vi, idx, rel)) {
            if (!scmp(rel, "desktop/Trash")) pop_add("Empty Trash...", A_EMPTY);
            else if (in_trash(rel)) {
                pop_add("Rename...", A_RENAME);
                pop_add("Move to Desktop", A_TODESK);
                pop_add("Delete Permanently...", A_DELPERM);
            } else {
                pop_add("Rename...", A_RENAME);
                pop_add("Move to Trash", A_TRASH);
            }
        }
    } else if (vi && !scmp(views[vi].path, "desktop/Trash")) {
        pop_add("Empty Trash...", A_EMPTY);
        pop_add("Clean Up Icons", A_CLEANUP);
        pop_add("Refresh", A_REFRESH);
    } else {
        pop_add("New Note", A_NEWNOTE);
        pop_add("New Folder...", A_NEWFOLDER);
        pop_add("Clean Up Icons", A_CLEANUP);
        if (wid < 0) pop_add("Settings", A_SETTINGS);
        pop_add("Refresh", A_REFRESH);
    }
    pop_fit();
}
static void editor_open_menu(int x, int y) {
    pop_begin(x, y, -1, -2, -1);
    scan_cat(3);
    int k = 0;
    for (int i = 0; i < cat_n && k < 16; i++)
        if (is_basic_ext(cat_ext[i])) {
            char l[44]; scpy(l, cat_rel[i][0] == 'c' ? "Tape:  " : "Disk:  "); scat(l, cat_name[i]);
            ncpy(prg_list[k], cat_rel[i], 220); pop_add(l, A_OPENPRG + k); k++;
        }
    if (!k) pop_add("(no .BAS files yet)", A_NONE);
    pop_fit();
}

/* ----- toolbars ----- */
static const char *TB_BASIC[5] = { "Run", "Stop", "Clear", "Reset", "Edit" };
static const char *TB_EDIT[7] = { "New", "Open", "Save", "Save As", "Run", "Example", "Help" };
static void tb_draw(const char **l, int n, int x, int y, int w) {
    rect(x, y, w, TOOLBAR, FACE);
    hline(x, y + TOOLBAR - 1, w, SHADOW);
    int bx = x + 3;
    for (int i = 0; i < n; i++) { int bw = sl(l[i]) * 8 + 14; button(bx, y + 2, bw, l[i], 0); bx += bw + 4; }
}
static int tb_hit(const char **l, int n, int x, int y, int px, int py) {
    if (py < y + 2 || py >= y + 20) return -1;
    int bx = x + 3;
    for (int i = 0; i < n; i++) { int bw = sl(l[i]) * 8 + 14; if (px >= bx && px < bx + bw) return i; bx += bw + 4; }
    return -1;
}
static int tb_end(const char **l, int n, int x) { int bx = x + 3; for (int i = 0; i < n; i++) bx += sl(l[i]) * 8 + 18; return bx; }

/* ----- settings window ----- */
static const char *SET_LBL[6] = { "Screen scale", "Icon size", "Colour theme", "Backdrop", "Boot screen", "BASIC screen" };
static const char *SET_OPT[6][6] = { { "Auto", "1x", "2x", "3x", "4x", 0 }, { "Small", "Large", 0 }, { "C64", "Amiga", "Teal", "Night", "Sunset", 0 },
                                     { "Dither", "Smooth", "Flat", 0 }, { "On", "Off", 0 }, { "40x25", "52x18", "80x30", 0 } };
static int set_get(int r) { switch (r) { case 0: return S.scale; case 1: return S.icons; case 2: return S.theme; case 3: return S.backdrop; case 4: return S.boot ? 0 : 1; default: return S.bsize; } }
static void core_resize(int cw, int ch);
static void basic_apply_size(void) {
    con_w = BSIZE_W[S.bsize]; con_h = BSIZE_H[S.bsize];
    basic_screen_reset();
    int i = find_win(T_BASIC, -1);
    if (i >= 0) { int cw, ch; basic_window_size(&cw, &ch); win[i].w = cw + 6; win[i].h = ch + 24; clamp_win(&win[i]); }
}
static void set_put(int r, int v) {
    switch (r) {
    case 0: S.scale = v; core_resize(last_cw, last_ch); break;
    case 1: S.icons = v; break;
    case 2: S.theme = v; break;
    case 3: S.backdrop = v; break;
    case 4: S.boot = v == 0; break;
    case 5: if (S.bsize != v) { S.bsize = v; basic_apply_size(); } break;
    }
    save_settings();
}
static int set_hit(int x, int y, int px, int py, int *row, int *opt) {
    for (int r = 0; r < 6; r++) {
        int by = y + 8 + r * 26, bx = x + 120;
        if (py < by || py >= by + 18) continue;
        for (int o = 0; SET_OPT[r][o]; o++) {
            int bw = sl(SET_OPT[r][o]) * 8 + 12;
            if (px >= bx && px < bx + bw) { *row = r; *opt = o; return 1; }
            bx += bw + 4;
        }
    }
    return 0;
}
static void draw_settings(int x, int y, int w, int h) {
    rect(x, y, w, h, FACE);
    for (int r = 0; r < 6; r++) {
        int by = y + 8 + r * 26, bx = x + 120;
        text(x + 10, by + 1, SET_LBL[r], 0x000000);
        for (int o = 0; SET_OPT[r][o]; o++) {
            int bw = sl(SET_OPT[r][o]) * 8 + 12;
            button(bx, by, bw, SET_OPT[r][o], set_get(r) == o);
            bx += bw + 4;
        }
    }
    text(x + 10, y + h - 22, "Saved automatically to settings.ini", 0x505050);
}

/* ----- window contents ----- */
static const char *DAYS[7] = { "SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT" };
static const char *MONS[12] = { "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC" };
static void two(char *o, int v) { o[0] = (char)('0' + v / 10 % 10); o[1] = (char)('0' + v % 10); }
static void draw_basic(int x, int y, int w, int h) {
    tb_draw(TB_BASIC, 5, x, y, w);
    const char *st = brun ? (bwait ? "INPUT" : "RUNNING") : "READY";
    text(x + w - sl(st) * 8 - 8, y + 3, st, brun ? 0x883932 : 0x505050);
    y += TOOLBAR; h -= TOOLBAR;
    rect(x, y, w, h, PAL[c_border]);
    rect(x + 8, y + 8, con_w * 8, con_h * 16, PAL[c_bg]);
    for (int r = 0; r < con_h; r++)
        for (int c = 0; c < con_w; c++)
            if (cch[r][c] != ' ') glyph(x + 8 + c * 8, y + 8 + r * 16, cch[r][c], PAL[ccl[r][c] & 15], 1);
    int t = top_win();
    if ((!brun || bwait) && t >= 0 && win[t].type == T_BASIC && (now_ms / 400) % 2 == 0) {
        int cx = x + 8 + ccolm * 8, cy = y + 8 + crow * 16;
        rect(cx, cy, 8, 16, PAL[c_fg]);
        if (cch[crow][ccolm] != ' ') glyph(cx, cy, cch[crow][ccolm], PAL[c_bg], 1);
    }
}
static void draw_clock(int x, int y, int w, int h) {
    Clock c; plat_clock(&c);
    rect(x, y, w, h, 0x101010);
    bevel(x, y, w, h, 0);
    char t[9]; two(t, c.hour); t[2] = ':'; two(t + 3, c.min); t[5] = ':'; two(t + 6, c.sec); t[8] = 0;
    if (c.sec % 2) t[2] = t[5] = ' ';
    textk(x + 8, y + 4, t, 0x94E089, 3);
    char d[24]; scpy(d, DAYS[c.wday % 7]); scpy(d + 3, " "); two(d + 4, c.day); scpy(d + 6, " ");
    scpy(d + 7, MONS[(c.mon + 11) % 12]); scpy(d + 10, " "); putint_s(d + 11, c.year);
    text(x + (w - sl(d) * 8) / 2, y + 52, d, 0x55A049);
}
static void draw_about(int x, int y, int w, int h) {
    rect(x, y, w, h, FACE);
    icon(x + 12, y + 12, IC_DISK, 2);
    textb(x + 60, y + 12, "Commodore 98 Workbench", TH.sel);
    text(x + 60, y + 30, "Release 2.0 with BASIC 7.0", 0x000000);
    text(x + 12, y + 60, "The late-90s Commodore that never", 0x000000);
    text(x + 12, y + 76, "was. A tiny native app: no emulator,", 0x000000);
    text(x + 12, y + 92, "no virtual machine, no runtime.", 0x000000);
    text(x + 12, y + 116, "Fan-made. Not affiliated with any", 0x505050);
    text(x + 12, y + 132, "owner of the Commodore name.", 0x505050);
}
static void draw_dialog(int x, int y, int w, int h) {
    rect(x, y, w, h, FACE);
    if (dlg_confirm()) {
        icon(x + 10, y + 8, IC_TRASH, 2);
        text(x + 52, y + 10, dlg.prompt, 0x000000);
        text(x + 52, y + 30, dlg.prompt2, 0x505050);
        button(x + w - 148, y + 66, 64, "Delete", 0);
        button(x + w - 78, y + 66, 70, "Cancel", 0);
        return;
    }
    text(x + 8, y + 6, dlg.prompt, 0x000000);
    rect(x + 8, y + 28, w - 16, 20, 0xFFFFFF); bevel(x + 8, y + 28, w - 16, 20, 0);
    text(x + 12, y + 30, dlg.buf, 0x000000);
    if ((now_ms / 400) % 2 == 0) rect(x + 12 + dlg.len * 8, y + 30, 2, 16, 0x000000);
    button(x + w - 148, y + 66, 64, "OK", 0);
    button(x + w - 78, y + 66, 70, "Cancel", 0);
    (void)h;
}
static void draw_editor(int x, int y, int w, int h, int focused) {
    tb_draw(TB_EDIT, 7, x, y, w);
    if (ed_status[0] && now_ms - ed_status_t < 4000) {
        int ex = tb_end(TB_EDIT, 7, x) + 4;
        clip(ex, y, x + w - ex, TOOLBAR);
        text(ex, y + 3, ed_status, 0x0000A0);
        clip(x, y, w, h);
    }
    ted_draw(&ed, x, y + TOOLBAR, w, h - TOOLBAR, 0xC8C0FF, C_BLUE, focused);
    if (!ed.len) {
        text(x + 12, y + TOOLBAR + 24, "Type a BASIC program here, for example:", 0x8070D0);
        text(x + 12, y + TOOLBAR + 48, "10 PRINT \"HELLO\"", 0x8070D0);
        text(x + 12, y + TOOLBAR + 64, "20 GOTO 10", 0x8070D0);
        text(x + 12, y + TOOLBAR + 88, "then press Run. Example loads a whole game.", 0x8070D0);
    }
}
static void draw_window(int a, int active) {
    Win *w = &win[a];
    noclip();
    frame3d(w->x, w->y, w->w, w->h);
    int tx = w->x + 3, ty = w->y + 3, tw = w->w - 6;
    for (int i = 0; i < tw; i++) {
        u32 c = active ? lerp(TH.ta, TH.tb, i, tw) : lerp(0x707070, 0xB8B8B8, i, tw);
        vline(tx + i, ty, 16, c);
    }
    clip(tx, ty, tw - 20, 16);
    textb(tx + 5, ty, w->title, active ? 0xFFFFFF : 0xE0E0E0);
    noclip();
    int bx = w->x + w->w - 19, by = ty + 1;
    rect(bx, by, 14, 14, FACE); bevel(bx, by, 14, 14, 1);
    for (int i = 0; i < 6; i++) { rect(bx + 4 + i, by + 4 + i, 1, 1, 0); rect(bx + 9 - i, by + 4 + i, 1, 1, 0); }
    int cx = win_cx(a), cy = win_cy(a), cw = win_cw(a), ch = win_chh(a);
    clip(cx, cy, cw, ch);
    switch (w->type) {
    case T_BASIC: draw_basic(cx, cy, cw, ch); break;
    case T_NOTE: ted_draw(&notes[w->data], cx, cy, cw, ch, 0x000000, 0xFFFFFF, active); break;
    case T_HELP: ted_draw(&helped, cx, cy, cw, ch, 0x000000, 0xFFFFE8, active); break;
    case T_CLOCK: draw_clock(cx, cy, cw, ch); break;
    case T_SETTINGS: draw_settings(cx, cy, cw, ch); break;
    case T_FOLDER: rect(cx, cy, cw, ch, 0xE4E4E4); draw_view(w->data, a, cx, cy, cw, ch, 0); break;
    case T_EDITOR: draw_editor(cx, cy, cw, ch, active); break;
    case T_DIALOG: draw_dialog(cx, cy, cw, ch); break;
    default: draw_about(cx, cy, cw, ch);
    }
    noclip();
    if (resizable(w->type)) {               /* resize grip */
        int gx = w->x + w->w - 12, gy = w->y + w->h - 12;
        for (int i = 0; i < 3; i++) for (int k = 0; k <= i; k++) {
            rect(gx + 8 - i * 3 + k * 3, gy + 8 - k * 3, 2, 2, SHADOW);
        }
    }
}

/* ----- desktop, menu bar, pointer ----- */
static int bg_key = -1;
static void build_backdrop(void) {
    static const int bayer[4][4] = { { 0, 8, 2, 10 }, { 12, 4, 14, 6 }, { 3, 11, 1, 9 }, { 15, 7, 13, 5 } };
    for (int y = 0; y < H; y++) {
        u32 *p = bgbuf + y * W;
        int t = y * 17 / (H > 0 ? H : 1);
        u32 sm = lerp(TH.da, TH.db, y, H);
        for (int x = 0; x < W; x++)
            p[x] = S.backdrop == 0 ? (bayer[y & 3][x & 3] < t ? TH.db : TH.da) : S.backdrop == 1 ? sm : TH.da;
    }
    bg_key = W * 7919 + H * 31 + S.theme * 7 + S.backdrop;
}
static void draw_desktop(void) {
    int key = W * 7919 + H * 31 + S.theme * 7 + S.backdrop;
    if (key != bg_key) build_backdrop();
    for (int i = MENUBAR * W, n = W * H; i < n; i++) fb[i] = bgbuf[i];
    draw_view(0, -1, 0, MENUBAR, W, desk_rect_h(), 1);
    const char *wm = "Commodore 98 Workbench Rel 2.0";
    text(W - 8 - sl(wm) * 8 + 1, H - 20 + 1, wm, 0x000000);
    text(W - 8 - sl(wm) * 8, H - 20, wm, lerp(TH.db, 0xFFFFFF, 2, 3));
}
static void draw_menubar(void) {
    noclip();
    rect(0, 0, W, MENUBAR - 1, FACE);
    hline(0, 0, W, HILITE);
    hline(0, MENUBAR - 1, W, DARK);
    for (int i = 0; i < 3; i++) {
        int x = BAR_X[i];
        if (pop.open && pop.bar == i) { rect(x, 1, BAR_W[i], MENUBAR - 2, TH.sel); textb(x + 8, 1, BAR_T[i], 0xFFFFFF); }
        else textb(x + 8, 1, BAR_T[i], i == 0 ? TH.sel : 0x000000);
    }
    Clock c; plat_clock(&c);
    char t[6]; two(t, c.hour); t[2] = ':'; two(t + 3, c.min); t[5] = 0;
    text(W - 52, 1, t, 0x000000);
    if (W >= 560) {
        char f[32]; putint_s(f, 61439 - prog_bytes()); scat(f, " BYTES FREE");
        text(W - 64 - sl(f) * 8, 1, f, 0x505050);
    }
}
static void draw_popup(void) {
    if (!pop.open) return;
    noclip();
    frame3d(pop.x, pop.y, pop.w, pop.n * 18 + 6);
    int hov = pop_item_at(mx, my);
    for (int i = 0; i < pop.n; i++) {
        int iy = pop.y + 3 + i * 18;
        int dis = pop.act[i] == A_NONE;
        if (hov == i && !dis) { rect(pop.x + 3, iy, pop.w - 6, 18, TH.sel); text(pop.x + 10, iy + 1, pop.lab[i], 0xFFFFFF); }
        else text(pop.x + 10, iy + 1, pop.lab[i], dis ? 0x808080 : 0x000000);
    }
}
static void draw_pointer(void) {
    noclip();
    for (int r = 0; r < 16; r++)
        for (int c = 0; c < 11; c++) {
            char p = POINTER[r][c];
            if (p == 'X') pset(mx + c, my + r, 0x000000);
            else if (p == 'W') pset(mx + c, my + r, 0xFFFFFF);
        }
}

/* ---------- boot + shutdown screens ---------- */
static void draw_boot(u32 el) {
    static const char *cmd1 = "LOAD\"WORKBENCH\",8,1";
    char lines[10][80]; int n = 0;
    int cols = (W - 80) / 8;
    int p1 = maxi(0, (cols - 32) / 2), p2 = maxi(0, (cols - 39) / 2);
    lines[n][0] = 0; n++;
    for (int i = 0; i < p1 && i < 40; i++) lines[n][i] = ' ';
    lines[n][mini(p1, 40)] = 0; scat(lines[n++], "**** COMMODORE 98 BASIC 7.0 ****");
    lines[n][0] = 0; n++;
    for (int i = 0; i < p2 && i < 40; i++) lines[n][i] = ' ';
    lines[n][mini(p2, 40)] = 0; scat(lines[n++], "64MB RAM SYSTEM  61439 BASIC BYTES FREE");
    lines[n][0] = 0; n++;
    scpy(lines[n++], "READY.");
    int typed = el < 600 ? 0 : (int)(el - 600) / 45;
    if (typed > sl(cmd1)) typed = sl(cmd1);
    ncpy(lines[n++], cmd1, typed + 1);
    if (el > 1700) scpy(lines[n++], "SEARCHING FOR WORKBENCH");
    if (el > 2300) scpy(lines[n++], "LOADING");
    if (el > 3100) scpy(lines[n++], "READY.");
    if (el > 3300) { int k = (int)(el - 3300) / 90; if (k > 3) k = 3; ncpy(lines[n++], "RUN", k + 1); }
    noclip();
    rect(0, 0, W, H, C_LBLUE);
    rect(32, 32, W - 64, H - 64, C_BLUE);
    for (int i = 0; i < n; i++) text(40, 40 + i * 16, lines[i], C_LBLUE);
    if ((el / 300) % 2 == 0) {
        int last = n - 1, cx = sl(lines[last]);
        if (el > 1500 && el < 3300) { last = n; cx = 0; }
        rect(40 + cx * 8, 40 + last * 16, 8, 16, C_LBLUE);
    }
}
static void draw_shutdown(void) {
    noclip();
    rect(0, 0, W, H, 0x000000);
    const char *a = "It's now safe to turn off", *b = "your Commodore.";
    textk((W - sl(a) * 16) / 2, H / 2 - 50, a, 0xDD8855, 2);
    textk((W - sl(b) * 16) / 2, H / 2 - 10, b, 0xDD8855, 2);
}

/* ---------- first run ---------- */
static const char *WELCOME =
"Welcome to Commodore 98!\n\n"
"This note lives in the \"desktop\" folder next to Commodore98.exe, and it saves itself as you type.\n\n"
"- Right-click the desktop for New Note and New Folder.\n"
"- Right-click a note or folder to rename it or move it to the Trash.\n"
"- Drag the corner of a note or folder window to resize it.\n"
"- Settings (top-left menu) changes the scale, icon size and colours.\n"
"- Game Maker is where you write your own BASIC games. Press Example to see one.\n"
"- In BASIC, LOAD\"$\",8 lists your floppies and RUN 1 starts the first one.\n";

static const char *EMU_README =
"Put the VICE C64 emulator in this folder to play real C64 games.\r\n\r\n"
"1. Download VICE for Windows (64-bit) from https://vice-emu.sourceforge.io/\r\n"
"2. Unzip it here, so this folder contains GTK3VICE-...\\bin\\x64sc.exe\r\n"
"   (x64sc.exe straight in this folder, or in a bin folder, works too).\r\n"
"3. In Commodore 98, type LOAD\"$\",8 and then RUN and the game's number.\r\n\r\n"
"Games go in the floppies or cassettes folder: .prg .d64 .t64 .tap .crt .g64 .d71 .d81\r\n"
"VICE loads and starts them automatically.\r\n";

/* ---------- core entry points used by the platform layer ---------- */
static void core_resize(int cw, int ch) {
    if (cw < 1 || ch < 1) return;
    last_cw = cw; last_ch = ch;
    int s = S.scale ? S.scale : (ch + 200) / 600;
    if (s < 1) s = 1;
    if (s > 4) s = 4;
    while (s > 1 && (cw / s < 640 || ch / s < 400)) s--;
    while ((cw + s - 1) / s > MAXW || (ch + s - 1) / s > MAXH) s++;
    SCALE = s;
    W = (cw + s - 1) / s; H = (ch + s - 1) / s;
    noclip();
    for (int i = 0; i < MAXWIN; i++) if (win[i].used) clamp_win(&win[i]);
}
static void core_init(u32 ms) {
    now_ms = ms; t0 = ms;
    rnd_state ^= ms * 2654435761u;
    load_settings();
    con_w = BSIZE_W[S.bsize]; con_h = BSIZE_H[S.bsize];
    plat_mkdir("cassettes"); plat_mkdir("floppies");
    if (!plat_exists("emulator")) { plat_mkdir("emulator"); plat_write("emulator/PUT VICE HERE.txt", EMU_README, sl(EMU_README)); }
    if (!plat_exists("desktop")) { plat_mkdir("desktop"); plat_write("desktop/Welcome.txt", WELCOME, sl(WELCOME)); }
    views[0].used = 1; scpy(views[0].path, "desktop");
    basic_screen_reset();
    if (!S.boot) { state = 1; open_basic_window(); }
}
static void core_frame(u32 ms) {
    now_ms = ms;
    if (state == 0 && ms - t0 > 3800) { state = 1; open_basic_window(); }
    if (state == 2 && ms - tshut > 2600) quit_req = 1;
    for (int i = 0; i < 4000 && brun && !bwait; i++) {
        if (bsleep_until && (int)(now_ms - bsleep_until) < 0) break;
        bsleep_until = 0;
        bstep();
    }
    for (int n = 0; n < MAXNOTE; n++)                         /* autosave notes */
        if (noteused[n] && notes[n].dirty && ms - notes[n].tedit > 800) { ted_save(&notes[n], notepath[n]); fs_gen++; }
    editor_title();
    if (state == 0) { draw_boot(ms - t0); return; }
    if (state == 2) { draw_shutdown(); return; }
    noclip();
    draw_desktop();
    for (int i = 0; i < nz; i++) draw_window(zord[i], i == nz - 1 && !desk_focus);
    if (idrag == 2) {
        int svi = idrag_win < 0 ? 0 : win[idrag_win].data;
        char lab[40]; int ic; item_info(svi, idrag_idx, lab, &ic, S.icons ? 10 : 17);
        noclip(); draw_item(mx - idrag_ox, my - idrag_oy, lab, ic, 1, 1);
    }
    draw_menubar();
    draw_popup();
    draw_pointer();
}
static void content_click(int a, int x, int y, int right) {
    Win *w = &win[a];
    int cx = win_cx(a), cy = win_cy(a), cw = win_cw(a), ch = win_chh(a);
    switch (w->type) {
    case T_BASIC: {
        if (right) return;
        int b = tb_hit(TB_BASIC, 5, cx, cy, x, y);
        if (b == 0) basic_command("RUN");
        else if (b == 1) { if (brun) b_stop(1); }
        else if (b == 2) { con_cls(); inlen = 0; if (bwait) con_puts("? "); }
        else if (b == 3) { if (brun) b_stop(0); basic_screen_reset(); }
        else if (b == 4) { if (nprog) editor_from_program(); else open_editor(); }
        break;
    }
    case T_NOTE: if (!right) ted_click(&notes[w->data], x - cx, y - cy, cw, ch); break;
    case T_EDITOR: {
        if (right) return;
        if (y < cy + TOOLBAR) {
            int b = tb_hit(TB_EDIT, 7, cx, cy, x, y);
            if (b == 0) {
                if (ed.dirty && !ed_new_armed) { ed_new_armed = 1; set_status("Unsaved changes! Press New again"); }
                else { ted_set(&ed, ""); edpath[0] = 0; ed_new_armed = 0; set_status("New program"); }
            }
            if (b == 1) editor_open_menu(x, cy + TOOLBAR);
            if (b == 2) editor_save(0);
            if (b == 3) editor_save(1);
            if (b == 4) editor_run();
            if (b == 5) { ted_set(&ed, EXAMPLE_GAME); edpath[0] = 0; ed.dirty = 1; set_status("Example loaded: press Run"); }
            if (b == 6) open_help();
            if (b != 0) ed_new_armed = 0;
        } else ted_click(&ed, x - cx, y - cy - TOOLBAR, cw, ch - TOOLBAR);
        break;
    }
    case T_SETTINGS: { int r, o; if (!right && set_hit(cx, cy, x, y, &r, &o)) set_put(r, o); break; }
    case T_FOLDER: {
        int i = view_hit(w->data, cx, cy, cw, ch, 0, x, y);
        if (right) { if (i >= 0) { sel_win = a; sel_idx = i; } open_context(a, i, x, y); return; }
        sel_win = a; sel_idx = i;
        if (i >= 0 && last_click_win == a && last_click_idx == i && now_ms - last_click < 450) { last_click_idx = -1; open_item(w->data, i); return; }
        last_click_win = a; last_click_idx = i; last_click = now_ms;
        if (i >= 0) begin_icon_drag(a, i, x, y);
        break;
    }
    case T_DIALOG:
        if (right) return;
        if (y >= cy + 66 && y < cy + 84) {
            if (x >= cx + cw - 148 && x < cx + cw - 84) dlg_ok();
            else if (x >= cx + cw - 78 && x < cx + cw - 8) close_win(a);
        }
        break;
    }
}
static void drop_icon(int x, int y) {
    int twin = -1, tvi = 0, rx = 0, ry = MENUBAR, rw = W, rh = desk_rect_h(), desk = 1;
    for (int i = nz - 1; i >= 0; i--) {
        int a = zord[i]; Win *w = &win[a];
        if (x >= w->x && x < w->x + w->w && y >= w->y && y < w->y + w->h) {
            if (w->type != T_FOLDER || y < win_cy(a)) return;          /* dropped on some other window */
            twin = a; tvi = w->data; rx = win_cx(a); ry = win_cy(a); rw = win_cw(a); rh = win_chh(a); desk = 0;
            break;
        }
    }
    int svi = idrag_win < 0 ? 0 : win[idrag_win].data;
    if (idrag_win < 0) pos_freeze(0, 0, MENUBAR, W, desk_rect_h(), 1);
    else pos_freeze(svi, win_cx(idrag_win), win_cy(idrag_win), win_cw(idrag_win), win_chh(idrag_win), 0);
    char srel[260], key[64];
    int sk = item_rel(svi, idrag_idx, srel);
    item_key(svi, idrag_idx, key);
    if (!sk && tvi != 0) return;                                        /* built-ins live on the desktop */
    int t = view_hit(tvi, rx, ry, rw, rh, desk, x, y);
    if (t >= 0 && !(tvi == svi && t == idrag_idx) && sk) {
        char trel[260];
        if (item_rel(tvi, t, trel) == 2) { move_item(srel, trel, 0); sel_idx = -1; return; }   /* onto a folder or the Trash */
    }
    int nx = x - idrag_ox - rx, ny = y - idrag_oy - ry;
    if (tvi == svi) { pos_set(views[svi].path, key, nx, ny); return; }
    char nrel[260];
    if (sk && move_item(srel, views[tvi].path, nrel)) { pos_set(views[tvi].path, path_base(nrel), nx, ny); sel_win = twin; sel_idx = -1; }
}
static void core_mouse(int x, int y, int ev) {  /* ev: 0 move, 1 left down, 2 left up, 3 right down */
    mx = x; my = y;
    if (state == 0) { if (ev == 1 || ev == 3) { state = 1; open_basic_window(); } return; }
    if (state == 2) { if (ev == 1) quit_req = 1; return; }
    if (ev == 0) {
        if (idrag == 1 && (x - idrag_sx) * (x - idrag_sx) + (y - idrag_sy) * (y - idrag_sy) > 16) idrag = 2;
        if (dragw >= 0) {
            Win *w = &win[dragw];
            if (dragmode == 1) { w->x = x - dragdx; w->y = y - dragdy; clamp_win(w); }
            else {
                int minw = w->type == T_EDITOR ? 460 : 200, minh = 100;
                w->w = maxi(minw, x - w->x + dragdx); w->h = maxi(minh, y - w->y + dragdy);
                if (w->x + w->w > W) w->w = W - w->x;
                if (w->y + w->h > H) w->h = H - w->y;
            }
        }
        return;
    }
    if (ev == 2) {
        dragw = -1;
        if (idrag == 2) drop_icon(x, y);
        idrag = 0;
        return;
    }
    idrag = 0;
    if (pop.open) {
        int it = pop_item_at(x, y);
        pop.open = 0;
        if (it >= 0) { do_action(pop.act[it]); return; }
        if (y < MENUBAR) for (int b = 0; b < 3; b++) if (x >= BAR_X[b] && x < BAR_X[b] + BAR_W[b] && b != pop.bar) { open_bar_menu(b); return; }
        return;
    }
    if (y < MENUBAR) {
        for (int b = 0; b < 3; b++) if (x >= BAR_X[b] && x < BAR_X[b] + BAR_W[b]) { open_bar_menu(b); return; }
        return;
    }
    for (int i = nz - 1; i >= 0; i--) {
        int a = zord[i]; Win *w = &win[a];
        if (x >= w->x && x < w->x + w->w && y >= w->y && y < w->y + w->h) {
            int dlgw = find_win(T_DIALOG, -1);
            focus(a); desk_focus = 0;
            if (dlgw >= 0 && a != dlgw) focus(dlgw);            /* keep the dialog on top */
            if (ev == 1) {
                int bx = w->x + w->w - 19, by = w->y + 4;
                if (x >= bx && x < bx + 14 && y >= by && y < by + 14) { close_win(a); return; }
                if (resizable(w->type) && x >= w->x + w->w - 14 && y >= w->y + w->h - 14) {
                    dragw = a; dragmode = 2; dragdx = w->x + w->w - x; dragdy = w->y + w->h - y; return;
                }
                if (y < w->y + 21) { dragw = a; dragmode = 1; dragdx = x - w->x; dragdy = y - w->y; return; }
            }
            if (y >= win_cy(a)) content_click(a, x, y, ev == 3);
            return;
        }
    }
    desk_focus = 1;
    int i = view_hit(0, 0, MENUBAR, W, desk_rect_h(), 1, x, y);
    if (ev == 3) { if (i >= 0) { sel_win = -1; sel_idx = i; } open_context(-1, i, x, y); return; }
    sel_win = -1; sel_idx = i;
    if (i >= 0 && last_click_win == -1 && last_click_idx == i && now_ms - last_click < 450) { last_click_idx = -1; open_item(0, i); return; }
    last_click_win = -1; last_click_idx = i; last_click = now_ms;
    if (i >= 0) begin_icon_drag(-1, i, x, y);
}
static TextEd *focused_ted(int *cols, int *rows) {
    int a = top_win(); if (a < 0) return 0;
    int cw = win_cw(a), ch = win_chh(a);
    if (win[a].type == T_NOTE) { *cols = (cw - 8) / 8; *rows = (ch - 8) / 16; return &notes[win[a].data]; }
    if (win[a].type == T_HELP) { *cols = (cw - 8) / 8; *rows = (ch - 8) / 16; return &helped; }
    if (win[a].type == T_EDITOR) { *cols = (cw - 8) / 8; *rows = (ch - TOOLBAR - 8) / 16; return &ed; }
    return 0;
}
static void core_char(int ch) {
    if (state == 0) { state = 1; open_basic_window(); return; }
    if (state == 2) { quit_req = 1; return; }
    if (pop.open) { if (ch == 27) pop.open = 0; return; }
    int a = top_win();
    if (a < 0 || desk_focus) {
        if (ch == 13 && sel_win == -1 && sel_idx >= 0) open_item(0, sel_idx);
        return;
    }
    int t = win[a].type, cols, rows;
    if (t == T_DIALOG) { dlg_char(ch); return; }
    if (t == T_BASIC) { basic_key(ch); return; }
    if (t == T_EDITOR && ch == 19) { editor_save(0); return; }
    if (t == T_FOLDER && ch == 13 && sel_win == a && sel_idx >= 0) { open_item(win[a].data, sel_idx); return; }
    TextEd *e = focused_ted(&cols, &rows);
    if (e) { if (e == &ed) ed_new_armed = 0; ted_key(e, ch, cols, rows); }
}
static void core_key(int k) {
    if (state != 1 || pop.open) return;
    int a = top_win(), cols, rows;
    if (a >= 0 && !desk_focus && win[a].type == T_BASIC) {
        static const int map[] = { 157, 29, 145, 17, 19, 0, 0, 0, 20 };
        if (brun && !bwait && k >= K_LEFT && k <= K_DEL && map[k - K_LEFT]) kq_push(map[k - K_LEFT]);
        return;
    }
    int files_focus = (desk_focus && sel_win == -1) || (a >= 0 && !desk_focus && win[a].type == T_FOLDER && sel_win == a);
    if (files_focus && sel_idx >= 0 && (k == K_F2 || k == K_DEL)) {
        int vi = sel_win == -1 ? 0 : win[sel_win].data;
        char rel[260];
        pop.ctxwin = sel_win; pop.ctxidx = sel_idx;
        if (k == K_F2) do_action(A_RENAME);
        else if (item_rel(vi, sel_idx, rel) && scmp(rel, "desktop/Trash")) do_action(in_trash(rel) ? A_DELPERM : A_TRASH);
        return;
    }
    if (desk_focus) return;
    TextEd *e = focused_ted(&cols, &rows);
    if (e) ted_key(e, k, cols, rows);
}
static void core_wheel(int notches) {
    for (int i = nz - 1; i >= 0; i--) {
        int a = zord[i]; Win *w = &win[a];
        if (mx >= w->x && mx < w->x + w->w && my >= w->y && my < w->y + w->h) {
            int cw = win_cw(a), ch = win_chh(a);
            if (w->type == T_NOTE) ted_scroll(&notes[w->data], -notches * 3, cw, ch);
            if (w->type == T_HELP) ted_scroll(&helped, -notches * 3, cw, ch);
            if (w->type == T_EDITOR) ted_scroll(&ed, -notches * 3, cw, ch - TOOLBAR);
            return;
        }
    }
}

/* =====================================================================
   Windows platform layer (no headers, no C runtime)
   ===================================================================== */
#ifdef _WIN32
#define WINAPI __stdcall
#define IMP __declspec(dllimport)
typedef __WCHAR_TYPE__ WCHAR;
typedef void *HANDLE;
typedef HANDLE HWND, HINSTANCE, HDC, HICON, HCURSOR, HBRUSH, HMENU;
typedef unsigned long long WPARAM;
typedef long long LPARAM, LRESULT;
typedef LRESULT (WINAPI *WNDPROC)(HWND, unsigned, WPARAM, LPARAM);
typedef struct { unsigned cbSize, style; WNDPROC lpfnWndProc; int cbClsExtra, cbWndExtra; HINSTANCE hInstance;
                 HICON hIcon; HCURSOR hCursor; HBRUSH hbrBackground; const WCHAR *lpszMenuName, *lpszClassName; HICON hIconSm; } WNDCLASSEXW;
typedef struct { int x, y; } POINT;
typedef struct { HWND hwnd; unsigned message; WPARAM wParam; LPARAM lParam; unsigned time; POINT pt; unsigned lPrivate; } MSG;
typedef struct { int left, top, right, bottom; } RECT;
typedef struct { HDC hdc; int fErase; RECT rcPaint; int fRestore, fIncUpdate; unsigned char rgbReserved[32]; } PAINTSTRUCT;
typedef struct { unsigned biSize; int biWidth, biHeight; unsigned short biPlanes, biBitCount; unsigned biCompression, biSizeImage;
                 int biXPelsPerMeter, biYPelsPerMeter; unsigned biClrUsed, biClrImportant; } BITMAPINFOHEADER;
typedef struct { BITMAPINFOHEADER h; unsigned colors[1]; } BITMAPINFO;
typedef struct { unsigned short wYear, wMonth, wDayOfWeek, wDay, wHour, wMinute, wSecond, wMilliseconds; } SYSTEMTIME;
typedef struct { unsigned lo, hi; } FILETIME;
typedef struct { unsigned dwFileAttributes; FILETIME c, a, w; unsigned nFileSizeHigh, nFileSizeLow, r0, r1;
                 WCHAR cFileName[260]; WCHAR cAlternateFileName[14]; } WIN32_FIND_DATAW;

IMP HINSTANCE WINAPI GetModuleHandleW(const WCHAR *);
IMP void WINAPI ExitProcess(unsigned);
IMP unsigned WINAPI GetTickCount(void);
IMP void WINAPI Sleep(unsigned);
IMP void WINAPI GetLocalTime(SYSTEMTIME *);
IMP HANDLE WINAPI FindFirstFileW(const WCHAR *, WIN32_FIND_DATAW *);
IMP int WINAPI FindNextFileW(HANDLE, WIN32_FIND_DATAW *);
IMP int WINAPI FindClose(HANDLE);
IMP int WINAPI CreateDirectoryW(const WCHAR *, void *);
IMP unsigned WINAPI GetModuleFileNameW(HINSTANCE, WCHAR *, unsigned);
IMP HANDLE WINAPI CreateFileW(const WCHAR *, unsigned, unsigned, void *, unsigned, unsigned, HANDLE);
IMP int WINAPI ReadFile(HANDLE, void *, unsigned, unsigned *, void *);
IMP int WINAPI WriteFile(HANDLE, const void *, unsigned, unsigned *, void *);
IMP int WINAPI CloseHandle(HANDLE);
IMP unsigned WINAPI GetFileAttributesW(const WCHAR *);
IMP int WINAPI MoveFileW(const WCHAR *, const WCHAR *);
IMP int WINAPI DeleteFileW(const WCHAR *);
IMP int WINAPI RemoveDirectoryW(const WCHAR *);
IMP int WINAPI SetFileAttributesW(const WCHAR *, unsigned);
IMP unsigned short WINAPI RegisterClassExW(const WNDCLASSEXW *);
IMP HWND WINAPI CreateWindowExW(unsigned, const WCHAR *, const WCHAR *, unsigned, int, int, int, int, HWND, HMENU, HINSTANCE, void *);
IMP LRESULT WINAPI DefWindowProcW(HWND, unsigned, WPARAM, LPARAM);
IMP int WINAPI PeekMessageW(MSG *, HWND, unsigned, unsigned, unsigned);
IMP int WINAPI TranslateMessage(const MSG *);
IMP LRESULT WINAPI DispatchMessageW(const MSG *);
IMP void WINAPI PostQuitMessage(int);
IMP HDC WINAPI GetDC(HWND);
IMP int WINAPI ReleaseDC(HWND, HDC);
IMP HDC WINAPI BeginPaint(HWND, PAINTSTRUCT *);
IMP int WINAPI EndPaint(HWND, const PAINTSTRUCT *);
IMP HCURSOR WINAPI LoadCursorW(HINSTANCE, const WCHAR *);
IMP HICON WINAPI LoadIconW(HINSTANCE, const WCHAR *);
IMP int WINAPI AdjustWindowRect(RECT *, unsigned, int);
IMP int WINAPI GetSystemMetrics(int);
IMP int WINAPI SetProcessDPIAware(void);
IMP HCURSOR WINAPI SetCursor(HCURSOR);
IMP HWND WINAPI SetCapture(HWND);
IMP int WINAPI ReleaseCapture(void);
IMP int WINAPI GetClientRect(HWND, RECT *);
IMP int WINAPI StretchDIBits(HDC, int, int, int, int, int, int, int, int, const void *, const BITMAPINFO *, unsigned, unsigned);
IMP HINSTANCE WINAPI ShellExecuteW(HWND, const WCHAR *, const WCHAR *, const WCHAR *, const WCHAR *, int);

int _fltused = 1;
void *memset(void *d, int c, unsigned long long n) { volatile unsigned char *p = d; while (n--) *p++ = (unsigned char)c; return d; }
void *memcpy(void *d, const void *s, unsigned long long n) { volatile unsigned char *p = d; const unsigned char *q = s; while (n--) *p++ = *q++; return d; }

static HWND g_hwnd;
static WCHAR basedir[300];
static int wlen(const WCHAR *s) { int n = 0; while (s[n]) n++; return n; }
static void wcpy(WCHAR *d, const WCHAR *s) { while ((*d++ = *s++)); }
static void fullpath(const char *rel, WCHAR *out, int max) {     /* UTF-8 relative path -> full UTF-16 path */
    wcpy(out, basedir);
    int n = wlen(out);
    const u8 *p = (const u8 *)rel;
    while (*p && n < max - 3) {
        unsigned c = *p++;
        if (c >= 0xC0) {
            int extra = c >= 0xF0 ? 3 : c >= 0xE0 ? 2 : 1;
            c &= extra == 3 ? 7 : extra == 2 ? 15 : 31;
            while (extra-- && (*p & 0xC0) == 0x80) c = (c << 6) | (*p++ & 63);
        }
        if (c == '/') c = '\\';
        if (c >= 0x10000) { c -= 0x10000; out[n++] = (WCHAR)(0xD800 + (c >> 10)); out[n++] = (WCHAR)(0xDC00 + (c & 1023)); }
        else out[n++] = (WCHAR)c;
    }
    out[n] = 0;
}
static void to_utf8(const WCHAR *s, char *o, int max) {
    int n = 0;
    for (int i = 0; s[i] && n < max - 5; i++) {
        unsigned c = s[i];
        if (c >= 0xD800 && c < 0xDC00 && s[i + 1] >= 0xDC00 && s[i + 1] < 0xE000) { c = 0x10000 + ((c - 0xD800) << 10) + (s[i + 1] - 0xDC00); i++; }
        if (c < 0x80) o[n++] = (char)c;
        else if (c < 0x800) { o[n++] = (char)(0xC0 | c >> 6); o[n++] = (char)(0x80 | (c & 63)); }
        else if (c < 0x10000) { o[n++] = (char)(0xE0 | c >> 12); o[n++] = (char)(0x80 | (c >> 6 & 63)); o[n++] = (char)(0x80 | (c & 63)); }
        else { o[n++] = (char)(0xF0 | c >> 18); o[n++] = (char)(0x80 | (c >> 12 & 63)); o[n++] = (char)(0x80 | (c >> 6 & 63)); o[n++] = (char)(0x80 | (c & 63)); }
    }
    o[n] = 0;
}
static void plat_clock(Clock *c) {
    SYSTEMTIME s; GetLocalTime(&s);
    c->year = s.wYear; c->mon = s.wMonth; c->day = s.wDay; c->wday = s.wDayOfWeek;
    c->hour = s.wHour; c->min = s.wMinute; c->sec = s.wSecond;
}
static void plat_dir(const char *rel, DirCb cb, void *ctx) {
    WCHAR pat[600]; fullpath(rel, pat, 590);
    int n = wlen(pat); pat[n++] = '\\'; pat[n++] = '*'; pat[n] = 0;
    WIN32_FIND_DATAW fd;
    HANDLE h = FindFirstFileW(pat, &fd);
    if (h == (HANDLE)(long long)-1) return;
    do {
        if (fd.cFileName[0] == '.' || (fd.dwFileAttributes & 0x6)) continue;   /* skip . .. hidden system */
        char nm[300]; to_utf8(fd.cFileName, nm, 300);
        cb(nm, (fd.dwFileAttributes & 0x10) != 0, ctx);
    } while (FindNextFileW(h, &fd));
    FindClose(h);
}
static int plat_read(const char *rel, char *buf, int max) {
    WCHAR p[600]; fullpath(rel, p, 600);
    HANDLE h = CreateFileW(p, 0x80000000u, 1, 0, 3, 0x80, 0);
    if (h == (HANDLE)(long long)-1) return -1;
    unsigned got = 0; int ok = ReadFile(h, buf, (unsigned)max, &got, 0);
    CloseHandle(h);
    return ok ? (int)got : -1;
}
static int plat_write(const char *rel, const char *data, int len) {
    WCHAR p[600]; fullpath(rel, p, 600);
    HANDLE h = CreateFileW(p, 0x40000000u, 0, 0, 2, path_base(rel)[0] == '.' ? 0x2 : 0x80, 0);   /* .positions is hidden */
    if (h == (HANDLE)(long long)-1) return 0;
    unsigned put = 0; int ok = len ? WriteFile(h, data, (unsigned)len, &put, 0) : 1;
    CloseHandle(h);
    return ok && (int)put == len;
}
static int plat_mkdir(const char *rel) { WCHAR p[600]; fullpath(rel, p, 600); return CreateDirectoryW(p, 0); }
static int del_tree(WCHAR *p) {                 /* p is a 600-WCHAR buffer, restored on return */
    unsigned a = GetFileAttributesW(p);
    if (a == 0xFFFFFFFFu) return 0;
    if (a & 1) SetFileAttributesW(p, a & ~1u);    /* clear read-only */
    if (!(a & 0x10)) return DeleteFileW(p);
    if (!(a & 0x400)) {                           /* never descend into junctions / links */
        int n = wlen(p);
        if (n > 560) return 0;
        p[n] = '\\'; p[n + 1] = '*'; p[n + 2] = 0;
        WIN32_FIND_DATAW fd;
        HANDLE h = FindFirstFileW(p, &fd);
        if (h != (HANDLE)(long long)-1) {
            do {
                if (fd.cFileName[0] == '.' && (fd.cFileName[1] == 0 || (fd.cFileName[1] == '.' && fd.cFileName[2] == 0))) continue;
                if (n + 2 + wlen(fd.cFileName) >= 598) continue;
                wcpy(p + n + 1, fd.cFileName);
                del_tree(p);
            } while (FindNextFileW(h, &fd));
            FindClose(h);
        }
        p[n] = 0;
    }
    return RemoveDirectoryW(p);
}
static int plat_delete(const char *rel) {
    if (!rel[0] || !path_under(rel, "desktop") || !scmp(rel, "desktop")) return 0;   /* only ever inside desktop/ */
    WCHAR p[600]; fullpath(rel, p, 600);
    return del_tree(p);
}
static int plat_exists(const char *rel) { WCHAR p[600]; fullpath(rel, p, 600); return GetFileAttributesW(p) != 0xFFFFFFFFu; }
static int plat_move(const char *from, const char *to) { WCHAR a[600], b[600]; fullpath(from, a, 600); fullpath(to, b, 600); return MoveFileW(a, b); }
static void wcat(WCHAR *d, const WCHAR *s) { wcpy(d + wlen(d), s); }
static int is_file(const WCHAR *p) { unsigned a = GetFileAttributesW(p); return a != 0xFFFFFFFFu && !(a & 0x10); }
static int find_vice(WCHAR *out) {        /* emulator\x64sc.exe, emulator\bin\, emulator\<any>\ or <any>\bin\ */
    static const WCHAR *exe[2] = { L"x64sc.exe", L"x64.exe" };
    WCHAR root[600]; wcpy(root, basedir); wcat(root, L"emulator\\");
    for (int e = 0; e < 2; e++) {
        wcpy(out, root); wcat(out, exe[e]); if (is_file(out)) return 1;
        wcpy(out, root); wcat(out, L"bin\\"); wcat(out, exe[e]); if (is_file(out)) return 1;
    }
    WCHAR pat[600]; wcpy(pat, root); wcat(pat, L"*");
    WIN32_FIND_DATAW fd;
    HANDLE h = FindFirstFileW(pat, &fd);
    if (h == (HANDLE)(long long)-1) return 0;
    int found = 0;
    do {
        if (!(fd.dwFileAttributes & 0x10) || fd.cFileName[0] == '.') continue;
        for (int e = 0; e < 2 && !found; e++) {
            wcpy(out, root); wcat(out, fd.cFileName); wcat(out, L"\\bin\\"); wcat(out, exe[e]); if (is_file(out)) found = 1;
            if (!found) { wcpy(out, root); wcat(out, fd.cFileName); wcat(out, L"\\"); wcat(out, exe[e]); if (is_file(out)) found = 1; }
        }
    } while (!found && FindNextFileW(h, &fd));
    FindClose(h);
    return found;
}
static int plat_emulate(const char *rel) {
    WCHAR exe[600], game[600], args[700], dir[600];
    if (!find_vice(exe)) return 0;
    fullpath(rel, game, 600);
    wcpy(args, L"-autostart \""); wcat(args, game); wcat(args, L"\"");
    wcpy(dir, exe); int n = wlen(dir); while (n > 0 && dir[n - 1] != '\\') n--; dir[n] = 0;
    return (long long)ShellExecuteW(g_hwnd, L"open", exe, args, dir, 1) > 32;
}
static int plat_shell(const char *rel) {
    WCHAR p[600]; fullpath(rel, p, 600);
    return (long long)ShellExecuteW(g_hwnd, L"open", p, 0, 0, 1) > 32;
}
static void blit(HDC dc) {
    BITMAPINFO bi;
    memset(&bi, 0, sizeof bi);
    bi.h.biSize = sizeof bi.h; bi.h.biWidth = W; bi.h.biHeight = -H; bi.h.biPlanes = 1; bi.h.biBitCount = 32;
    StretchDIBits(dc, 0, 0, W * SCALE, H * SCALE, 0, 0, W, H, fb, &bi, 0, 0x00CC0020);
}
static int mxs(LPARAM l) { return (short)(l & 0xFFFF) / SCALE; }
static int mys(LPARAM l) { return (short)((l >> 16) & 0xFFFF) / SCALE; }
static LRESULT WINAPI wndproc(HWND h, unsigned m, WPARAM w, LPARAM l) {
    switch (m) {
    case 0x0010: quit_req = 1; return 0;                                 /* WM_CLOSE */
    case 0x0002: PostQuitMessage(0); return 0;                           /* WM_DESTROY */
    case 0x0005: if (w != 1) core_resize((int)(l & 0xFFFF), (int)((l >> 16) & 0xFFFF)); return 0;  /* WM_SIZE */
    case 0x0014: return 1;                                               /* WM_ERASEBKGND */
    case 0x000F: { PAINTSTRUCT ps; HDC dc = BeginPaint(h, &ps); blit(dc); EndPaint(h, &ps); return 0; }
    case 0x0020: if ((l & 0xFFFF) == 1) { SetCursor(0); return 1; } break; /* hide the arrow in the client area */
    case 0x0200: core_mouse(mxs(l), mys(l), 0); return 0;
    case 0x0201: SetCapture(h); core_mouse(mxs(l), mys(l), 1); return 0;
    case 0x0202: ReleaseCapture(); core_mouse(mxs(l), mys(l), 2); return 0;
    case 0x0204: core_mouse(mxs(l), mys(l), 3); return 0;               /* right button */
    case 0x020A: core_wheel((short)((w >> 16) & 0xFFFF) / 120); return 0;
    case 0x0102: core_char((int)w); return 0;                           /* WM_CHAR */
    case 0x0100: {                                                       /* WM_KEYDOWN */
        int k = 0;
        switch ((int)w) {
        case 0x25: k = K_LEFT; break; case 0x27: k = K_RIGHT; break; case 0x26: k = K_UP; break; case 0x28: k = K_DOWN; break;
        case 0x24: k = K_HOME; break; case 0x23: k = K_END; break; case 0x21: k = K_PGUP; break; case 0x22: k = K_PGDN; break;
        case 0x2E: k = K_DEL; break; case 0x71: k = K_F2; break;
        }
        if (k) { core_key(k); return 0; }
        break;
    }
    }
    return DefWindowProcW(h, m, w, l);
}
void WINAPI start(void) {
    SetProcessDPIAware();
    HINSTANCE hi = GetModuleHandleW(0);
    unsigned n = GetModuleFileNameW(0, basedir, 280);
    while (n > 0 && basedir[n - 1] != '\\') n--;
    basedir[n] = 0;
    core_init(GetTickCount());
    WNDCLASSEXW wc;
    memset(&wc, 0, sizeof wc);
    wc.cbSize = sizeof wc; wc.style = 0x0023; wc.lpfnWndProc = wndproc; wc.hInstance = hi;
    wc.hIcon = LoadIconW(hi, (const WCHAR *)1); wc.hIconSm = wc.hIcon;
    wc.hCursor = LoadCursorW(0, (const WCHAR *)32512);
    wc.lpszClassName = L"Commodore98";
    RegisterClassExW(&wc);
    int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
    unsigned style = 0x00CF0000;                                        /* resizable, maximizable */
    RECT r = { 0, 0, sw * 4 / 5, sh * 4 / 5 };
    AdjustWindowRect(&r, style, 0);
    int ww = r.right - r.left, wh = r.bottom - r.top;
    g_hwnd = CreateWindowExW(0, L"Commodore98", L"Commodore 98", style | 0x10000000,
                             (sw - ww) / 2, (sh - wh) / 2, ww, wh, 0, 0, hi, 0);
    RECT cr; GetClientRect(g_hwnd, &cr); core_resize(cr.right, cr.bottom);
    MSG msg;
    while (!quit_req) {
        while (PeekMessageW(&msg, 0, 0, 0, 1)) {
            if (msg.message == 0x0012) quit_req = 1;
            TranslateMessage(&msg); DispatchMessageW(&msg);
        }
        core_frame(GetTickCount());
        HDC dc = GetDC(g_hwnd); blit(dc); ReleaseDC(g_hwnd, dc);
        Sleep(15);
    }
    for (int i = 0; i < MAXNOTE; i++) if (noteused[i] && notes[i].dirty) ted_save(&notes[i], notepath[i]);
    ExitProcess(0);
}

/* =====================================================================
   Test harness (non-Windows): scripted input, writes PPM screenshots
   ===================================================================== */
#else
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
static void plat_clock(Clock *c) { c->year = 1998; c->mon = 10; c->day = 27; c->wday = 2; c->hour = 14; c->min = 35; c->sec = 7; }
static void plat_dir(const char *rel, DirCb cb, void *ctx) {
    DIR *d = opendir(rel); if (!d) return;
    struct dirent *e;
    while ((e = readdir(d))) {
        if (e->d_name[0] == '.') continue;
        char p[600]; struct stat st; snprintf(p, sizeof p, "%s/%s", rel, e->d_name);
        int isdir = stat(p, &st) == 0 && S_ISDIR(st.st_mode);
        cb(e->d_name, isdir, ctx);
    }
    closedir(d);
}
static int plat_read(const char *rel, char *buf, int max) { FILE *f = fopen(rel, "rb"); if (!f) return -1; int n = (int)fread(buf, 1, max, f); fclose(f); return n; }
static int plat_write(const char *rel, const char *data, int len) { FILE *f = fopen(rel, "wb"); if (!f) return 0; fwrite(data, 1, len, f); fclose(f); return 1; }
static int plat_mkdir(const char *rel) { return mkdir(rel, 0755) == 0; }
static int plat_exists(const char *rel) { struct stat st; return stat(rel, &st) == 0; }
static int plat_move(const char *from, const char *to) { return rename(from, to) == 0; }
static int plat_delete(const char *rel) {
    if (!path_under(rel, "desktop") || !scmp(rel, "desktop")) return 0;
    struct stat st; if (lstat(rel, &st)) return 0;
    if (!S_ISDIR(st.st_mode)) return unlink(rel) == 0;
    DIR *d = opendir(rel);
    if (d) {
        struct dirent *e;
        while ((e = readdir(d))) {
            if (!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
            char p[700]; snprintf(p, sizeof p, "%s/%s", rel, e->d_name); plat_delete(p);
        }
        closedir(d);
    }
    return rmdir(rel) == 0;
}
static int plat_shell(const char *rel) { fprintf(stderr, "shell-open %s\n", rel); return 0; }
static int plat_emulate(const char *rel) {
    if (!plat_exists("emulator/x64sc.exe")) return 0;
    fprintf(stderr, "vice -autostart %s\n", rel); return 1;
}
static void snap(const char *fn) {
    FILE *f = fopen(fn, "wb");
    fprintf(f, "P6 %d %d 255\n", W, H);
    for (int i = 0; i < W * H; i++) { u32 c = fb[i]; fputc(c >> 16 & 255, f); fputc(c >> 8 & 255, f); fputc(c & 255, f); }
    fclose(f);
}
int main(void) {
    u32 t = 1000; char line[1024];
    core_init(t);
    core_resize(640, 400);
    while (fgets(line, sizeof line, stdin)) {
        int n = (int)strlen(line), x = 0, y = 0;
        while (n && (line[n - 1] == '\n' || line[n - 1] == '\r')) line[--n] = 0;
        if (!n) continue;
        const char *a = n > 2 ? line + 2 : "";
        switch (line[0]) {
        case 'w': { int k = atoi(a); for (int i = 0; i < k; i++) { t += 16; core_frame(t); } break; }
        case 'm': sscanf(a, "%d %d", &x, &y); core_mouse(x, y, 0); break;
        case 'c': sscanf(a, "%d %d", &x, &y); core_mouse(x, y, 0); core_mouse(x, y, 1); core_mouse(x, y, 2); t += 16; core_frame(t); break;
        case 'R': sscanf(a, "%d %d", &x, &y); core_mouse(x, y, 0); core_mouse(x, y, 3); t += 16; core_frame(t); break;
        case 'D': sscanf(a, "%d %d", &x, &y); core_mouse(x, y, 0); core_mouse(x, y, 1); core_mouse(x, y, 2); t += 100; core_frame(t);
                  core_mouse(x, y, 1); core_mouse(x, y, 2); t += 16; core_frame(t); break;
        case 'p': sscanf(a, "%d %d", &x, &y); core_mouse(x, y, 0); core_mouse(x, y, 1); break;
        case 'r': sscanf(a, "%d %d", &x, &y); core_mouse(x, y, 0); core_mouse(x, y, 2); break;
        case 't': for (const char *p = a; *p; p++) core_char((u8)*p); break;
        case 'e': core_char(13); break;
        case 'k': core_char(atoi(a)); break;
        case 'K': core_key(K_LEFT + atoi(a)); break;
        case 'W': core_wheel(atoi(a)); break;
        case 'z': sscanf(a, "%d %d", &x, &y); core_resize(x, y); break;
        case 's': t += 16; core_frame(t); snap(a); break;
        }
    }
    printf("quit=%d W=%d H=%d scale=%d\n", quit_req, W, H, SCALE);
    return 0;
}
#endif
